$(function(){
    $('.over').hover(
        function(){
            var src = $(this).attr('src');
            var src_o = src.substr(0, src.lastIndexOf('.')) + '_o' +
            src.substring(src.lastIndexOf('.'));
            $(this).attr('src',src_o);
        },
        function(){
            var src = $(this).attr('src');
            var src = src.substr(0, src.lastIndexOf('.')-2) +
            src.substring(src.lastIndexOf('.'));
            $(this).attr('src',src);
        }
    )
});

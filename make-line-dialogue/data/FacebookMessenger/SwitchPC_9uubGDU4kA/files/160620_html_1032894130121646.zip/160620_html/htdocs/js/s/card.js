$(function(){
	columnfix();
	cardSet();
});


function cardSet(){
	//インタラクティブカード
	var cardHeight = $(".card-list > div").eq(0).innerHeight();
	$(".card-list").css({
		"height" : cardHeight
	});
	
	$(".card-close a").click(function(){
		var cardIndex = $(this).closest("div").index();
		var cardHeight = $(this).closest("div").innerHeight();
		var cardMove = cardHeight * -1;
		$(this).closest("div").css({
			"top":cardHeight,
			"opacity":"0"
		});
		if($(".card-list > div").eq(cardIndex + 1).length){
			$(".card-list > div").eq(cardIndex + 1).css({
				"marginTop":cardMove,
				"opacity":"1"
			});
			$(".card-list").css({
				"height" : $(".card-list > div").eq(cardIndex + 1).innerHeight()
			});
		}else{
			setTimeout(function(){
				$(".card-list").css({
					"height" : "0"
				});
			},500);
		}
		return false;
	});
}

function jobCardSet(){
	//求人カード
	var baseTarget = $(".main-pick-up-list > div").eq(0);
	var cardHeight = baseTarget.innerHeight();
	var cardMove = cardHeight * -1;
	baseTarget.css({
		"top":cardHeight,
		"opacity":"0"
	});
	if(baseTarget.next("div").length){
		baseTarget.next("div").css({
			"marginTop":cardMove
		});
		setTimeout(function(){
			baseTarget.next("div").removeClass("is-hidden");
		},500);
	}
}

function columnfix(){
	if($(".fixH").length > 0){
		$(".fixH").each(function(){
			var fixH = 0;
			var fixTarget = $(this).children("ul,div");
			fixTarget.each(function(){
				if($(this).height() > fixH) fixH = $(this).height();
			});
			fixTarget.height(fixH);
		});
	}
}


//job hoverアクション
$(function(){
	var job = $('.job');
	$('.job').on({
		'mouseover': function(){
			$(this).find('.job-submenu-top').stop().animate( { height: 'toggle', opacity: 'toggle' }, 300 );
			if($('.job-contents').hasClass('in')) {
				$(this).find('.job-submenu-top').not().hide();
				$(this).find('.job-submenu-top').stop().show();
			}
		},
		'mouseout': function(){
			$(this).find('.job-submenu-top').stop().animate( { height: 'toggle', opacity: 'toggle' }, 300 );
			if ($('.panel-collapse').hasClass('in')) {
				$(this).find('.job-submenu-top').not().hide();
				$(this).find('.job-submenu-top').stop().show();
			}
		}
	});
});

//.submenu-infoボタンクリック処理
$(function(){
	$('.submenu-info').click(function(){
		if(!$(this).parent().parent().find('.job-contents').hasClass('in')){
			$(this).prepend('<div class="dummy"></div>');
			$(this).parent().parent().find('.job-description').hide();
			$(this).parent().parent().find('.job-description-open').fadeIn();
		}
	});
	$('.panel-title').click(function(){
		if($(this).parent().parent().hasClass('in')){
			$(this).parent().parent().parent().parent().find('.dummy').remove();
			$(this).parent().parent().parent().parent().find('.job-description-open').hide();
			$(this).parent().parent().parent().parent().find('.job-description').fadeIn();
		} 
	});
})




// job panel アコーディオン 下部ボタン処理
$(function(){
	$('#job-accordion-bottom').click(function () {
		$('#job-accordion-top').addClass('collapsed');
	});
	$('.job-contents').on('hidden.bs.collapse', function () {
		$('.page-index #job-accordion-top').removeClass('collapsed');
		$('#job-accordion-bottom').removeClass('collapsed');
		var targetY = $('.job-contents').offset().top;
		$("html,body").animate({scrollTop:targetY-300});
	})
});





//job panel スカウト一覧ページ固有
$(function(){
	$('.page-action-scoutlists .job').on({
		'mouseover': function(){
			$(this).find('.panel-heading').stop().animate( { height: 'toggle', opacity: 'toggle' }, 300 );
			if($('.job-contents').hasClass('in')) {
				$(this).find('.panel-heading').not().hide();
				$(this).find('.panel-heading').stop().show();
			} else {
			}
		},
		'mouseout': function(){
			$(this).find('.panel-heading').stop().animate( { height: 'toggle', opacity: 'toggle' }, 300 );
			if($('.job-contents').hasClass('in')) {
				$(this).find('.panel-heading').not().hide();
				$(this).find('.panel-heading').stop().show();
			} else {
			}
		}
	});
});

$(function(){
	$('.page-action-scoutlists .panel-heading').click(function(event) {
		if($(this).parent().parent().parent().find('.job-contents').hasClass('in')){
			$(this).find('#job-accordion-top').addClass('collapsed');
			$(this).find('#job-accordion-top').html("詳しく表示<i>&gt;</i>");
		} else {
			$(this).find('#job-accordion-top').removeClass('collapsed');

			$(this).find('#job-accordion-top').html("閉じる<i>&gt;</i>");
		}
	});
})
$(function(){
	$('.page-action-scoutlists .panel-bottom').click(function(event) {
		if($(this).parent().parent().parent().find('.job-contents').hasClass('in')){
			$(this).parent().parent().parent().find('.status-1').hide();
			$(this).parent().parent().parent().find('.status-0').show();
			$(this).parent().parent().find('#job-accordion-top').addClass('collapsed');
			$(this).parent().parent().find('#job-accordion-top').html("詳しく表示<i>&gt;</i>");
		} else {
			$(this).parent().parent().find('#job-accordion-top').removeClass('collapsed');

			$(this).parent().parent().find('#job-accordion-top').html("閉じる<i>&gt;</i>");
			$(this).parent().parent().parent().find('.status-0').hide();
			$(this).parent().parent().parent().find('.status-1').show();
		}
	});
})

$(function(){
	$('.page-action-scoutlists .message-toggle').click(function(){
		$(".btn-messagetoggle").toggle();
	});
});

$(function(){
	$('.page-action-scoutlists .job').hover(function(){
		if($(this).children().hasClass('blur')){
			$(this).find('.job-submenu').stop().hide();
		};
	});
});



//job panel マッチング一覧ページ固有
$(function(){
	$('.page-action-matchinglists .job').on({
		'mouseover': function(){
			$(this).find('.panel-heading').stop().animate( { height: 'toggle', opacity: 'toggle' }, 300 );
			if($('.job-contents').hasClass('in')) {
				$(this).find('.panel-heading').not().hide();
				$(this).find('.panel-heading').stop().show();
			} else {
			}
		},
		'mouseout': function(){
			$(this).find('.panel-heading').stop().animate( { height: 'toggle', opacity: 'toggle' }, 300 );
			if($('.job-contents').hasClass('in')) {
				$(this).find('.panel-heading').not().hide();
				$(this).find('.panel-heading').stop().show();
			} else {
			}
		}
	});
});

//マッチング一覧ページ固有 ボタンクリック処理
$(function(){
	$('.page-action-matchinglists .panel-heading').click(function(event) {
		//タブ遷移
		$(this).parent().parent().parent().find('.job-contents li').removeClass('active');
		$(this).parent().parent().parent().find('.job-contents .tab-content .tab-pane').removeClass('active');
		$(this).parent().parent().parent().find('.job-contents li:first-child').addClass('active');
		$(this).parent().parent().parent().find('.job-contents .tab-content .tab-pane:first-child').addClass('active');

		if($(this).parent().parent().parent().find('.job-contents').hasClass('in')){
			$(this).parent().find('.status-1').hide();
			$(this).parent().find('.status-0').show();
			$(this).find('#job-accordion-top').addClass('collapsed');
			$(this).find('#job-accordion-top').html("詳しく表示<i>&gt;</i>");
		} else {
			$(this).find('#job-accordion-top').removeClass('collapsed');

			$(this).find('#job-accordion-top').html("閉じる<i>&gt;</i>");
			$(this).parent().find('.status-0').hide();
			$(this).parent().find('.status-1').show();
		}
	});
})
$(function(){
	$('.page-action-matchinglists .panel-bottom').click(function(event) {
		if($(this).parent().parent().parent().find('.job-contents').hasClass('in')){
			$(this).parent().parent().parent().parent().find('.status-1').hide();
			$(this).parent().parent().parent().parent().find('.status-0').show();
			$(this).parent().parent().parent().parent().find('#job-accordion-top').addClass('collapsed');
			$(this).parent().parent().parent().parent().find('#job-accordion-top').html("詳しく表示<i>&gt;</i>");
		} else {
			$(this).parent().parent().parent().parent().find('#job-accordion-top').removeClass('collapsed');

			$(this).parent().parent().parent().parent().find('#job-accordion-top').html("閉じる<i>&gt;</i>");
			$(this).parent().parent().parent().parent().find('.status-0').hide();
			$(this).parent().parent().parent().parent().find('.status-1').show();
		}
	});
})
$(function(){
	$('.page-action-matchinglists .job-status a').click(function(event) {
		//タブ遷移
		$(this).parent().parent().parent().find('.job-contents li').removeClass('active');
		$(this).parent().parent().parent().find('.job-contents .tab-content .tab-pane').removeClass('active');
		$(this).parent().parent().parent().find('.job-contents li:last-child').addClass('active');
		$(this).parent().parent().parent().find('.job-contents .tab-content .tab-pane:last-child').addClass('active');

		//
		if($(this).parent().parent().parent().find('.panel-job .job-contents').hasClass('in')){
			$(this).parent().parent().parent().parent().find('.panel-title #job-accordion-top').addClass('collapsed');
			$(this).parent().parent().parent().parent().find('.panel-title #job-accordion-top').html("詳しく表示<i>&gt;</i>");
			$(this).parent().find('.status-1').hide();
			$(this).parent().find('.status-0').show();
		} else {
			$(this).parent().parent().parent().parent().find('.panel-title #job-accordion-top').removeClass('collapsed');
			$(this).parent().parent().parent().parent().find('.panel-title #job-accordion-top').html("閉じる<i>&gt;</i>");
			$(this).parent().find('.status-0').hide();
			$(this).parent().find('.status-1').show();
		}
	});
})




//checkbox全選択、全解除
$(function(){
	$('.all-check input,.all-check label').click(function(){
		var items = $(this).closest('.tab-pane').find('.checkbox-lists input');
		if($(this).is(':checked')) {
				$(items).prop('checked', true);
		} else {
				$(items).prop('checked', false);
		}
	});
});


//セレクトボックス カスタマイズ

$(function(){
	$('.design-select-box').easySelectBox();
});


$(function(){
	$('.tab-pane-body input').change(function(){
		var index = $(this).closest('.tab-pane').index();
		// var $count = $(this).closest('.tab-pane input[type=checkbox]:checked').length;
		if ($(this).is(':checked')) {
			$(this).parent().parent().parent().parent().parent().parent().parent().find('.nav-pills li').eq(index).find('.check').show();
		} else if($(this).parent().parent().parent().parent().parent().find('.tab-pane.active input[type=checkbox]:checked').length < 1){
			$(this).parent().parent().parent().parent().parent().parent().parent().find('.nav-pills li').eq(index).find('.check').hide();
		} 
	});
});


//サイドコンテンツ グラフ
$(function(){
	var data = [
	{
		value: 40,
		color:"#ffe7cc"
	},
	{
		value: 60,
		color: "#ff9c38"
	}
	]

	var ctx = $("#status-chart").get(0).getContext("2d");
	new Chart(ctx).Pie(data, {
		animationEasing : "easeOutQuart",
		animateScale: true,
		segmentShowStroke : false
	});
});


//カレント表記
//サイドナビのaタグ指定とURLが一致するとカレントになる。
$(function(){
	$page = $.url().attr('file');
	if(!$page) {
		$page = '/';
	}
	$('.nav-lists a').each(function(){
		var $href = $(this).attr('href');
		if ( ($href == $page) || ($href == '') ) {
			$(this).addClass('current');
		} else {
			$(this).removeClass('current');
		}
	});
});


//完了しました。
$(function(){
	$('.page-index .job').eq(0).find('.submenu-like').click(function(event) {
		$('.popup-complete').fadeIn();
		$('.popup-complete').click(function(event) {
			$('.popup-complete').fadeOut();
		});
		setTimeout(function() {
			$('.popup-complete').fadeOut();
		}, 2000);

	});
})


//エラー
$(function(){
	$('.page-index .job').eq(1).find('.submenu-info').click(function(event) {
		$('.error-modal').modal();
	});
})


//input ファイル名表示
$(function() {
	$('.input-file').on("change", function() {
		var file = this.files[0];
		if(file != null) {
			$(this).parent().parent().parent().before("<div class='file-name'>"+ file.name +"<a href='javascript:void(0);'>☓</a></div>") 
			$(this).parent().parent().parent().parent().find('.file-name a').click(function(){
				var index = $(this).parent().parent().parent().parent().find('.file-name a').index(this);
				$(this).parent().parent().parent().parent().find('.file-name').eq(index).hide();
			})
		}
	});
});



(function( $ ){
	$.fn.valList = function(){
		return $.map( this, function (elem) {
			return elem.value || "";
		}).join( '<br>' );
	};
})( jQuery );

$(function(){
	$('#modal-job-01 .btn-main-color').click(function(){
		$('.search-01 .cheked-lists').empty();
		$('.search-01 .cheked-lists').append($('#modal-job-01 input:checked').valList());
	});
	$('#modal-job-02 .btn-main-color').click(function(){
		$('.search-02 .cheked-lists').empty();
		$('.search-02 .cheked-lists').append($('#modal-job-02 input:checked').valList());
	});
})




	
$(function(){
	$('.offer-search-submit').click(function(){
		$('.offer-search').hide();
		$('.offer-retry-btn').fadeIn();
	});
	$('.offer-retry-btn').click(function(){
		$(this).hide();
		$('.offer-search').fadeIn();
	});
})


/* ===============================================
.page-profile　
=============================================== */
$(function(){
	$('.page-profile #page-profile-nav-02 .tab-pane-header a').click(function(){
		$('.offer-search-new-container').fadeIn();
	});
	$('.page-profile .offer-search-new .form-submit').click(function(){
		$('.offer-search-new-container').hide();
	});
	$('.page-profile .offer-search-new .btn-cancel').click(function(){
		$('.offer-search-new-container').hide();
	});
})

//希望条件
$(function(){
	$('.page-profile .profile-terms-container .edit').click(function(){
		$(this).parent().parent().parent().find('.edit-toggle').toggle();
	});
	$('.page-profile .profile-terms-container .delete').click(function(){
		$(this).parent().parent().parent('.profile-terms-container').remove();
	});
})




$(function(){
	$('.page-profile .offer-search #modal-job-01 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').append($('#modal-job-01 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-02 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').append($('#modal-job-02 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-03 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').append($('#modal-job-03 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-04 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').append($('#modal-job-04 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-05 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').append($('#modal-job-05 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-06 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').append($('#modal-job-06 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-07 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-01 .cheked-lists').append($('#modal-job-07 input:checked').valList());
	});
	$('.page-profile .offer-search #modal-job-08 .btn-main-color').click(function(event) {
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').empty();
		$(this).parent().parent().parent().parent().parent().parent().find('.search-02 .cheked-lists').append($('#modal-job-08 input:checked').valList());
	});
})
/* ===============================================
.page-profile-edit
=============================================== */
//プロフィール
$(function(){
	//写真を削除
	$('.profile_outline-edit .photo-remove a').on('click',function(){
		$(this).parent().parent().parent().parent().parent().find('.profile-picture').remove();
		return false;
	})
})

//職歴
$(function(){
	var $newblock = $('.profile_professional-edit .newblock').clone(true);
	$(document).on('click','.profile_professional-edit .add-cp',function(){
		$newblock.clone(true).insertBefore(this).show();
		$(this).prev('.newblock').find('.easy-select-box').remove();
		$(this).prev('.newblock').find('.design-select-box').easySelectBox();
	});
	var $newlistblock = $('.profile_professional-edit .newblock .business-lists').clone(true);
	$(document).on('click','.profile_professional-edit .add-list',function(){
		$newlistblock.clone(true).insertBefore(this).show();
		$(this).prev().find('.easy-select-box').remove();
		$(this).prev().find('.design-select-box').easySelectBox();
	});
	$(document).on('click','.profile_professional-edit .clear-btn', function(){
		$(this).parent().parent().parent().remove();
	});

	// $('.profile_professional-edit .add-list').click(function(){
	// 	$(this).prev('.business-lists').clone(true).insertBefore(this);
	// })

	// var $newcp = $('.profile_professional-edit .cp-block-new').clone(true);
	// $('.profile_professional-edit .add-cp').click(function(){
	// 	$newcp.clone(true).insertBefore(this).show();
	// })
	
	//@entacl/////////////////////////////////////////////////////////////////
	var modal_job_sample_array = [];
	$("#modal-job-sample textarea").each(function(i) {
		modal_job_sample_array[i] = $(this).val();
	});
	
	var select_business_lists = -1;
	$(document).on('click', '.profile_professional-edit .business-lists .job-sample-btn', function() {
		select_business_lists = $('.profile_professional-edit .business-lists .job-sample-btn').index(this);
	});
	$("#modal-job-sample .btn-refact").click(function() {
		$('.profile_professional-edit .business-lists textarea').eq(select_business_lists).html($(this).parent().parent().find("textarea").val());
		$("#modal-job-sample textarea").each(function(i) {
			$(this).val(modal_job_sample_array[i]);
		});
	});
	//@entacl/////////////////////////////////////////////////////////////////
})


//経験職種・業種
$(function(){
	$('.profile_trade-edit #modal-job-01 .btn-main-color').click(function(event) {
		var checkedLists = [];
		$('.profile_trade-edit #modal-job-01 input:checked').each(function(){
			checkedLists.push($(this).val());
		});

		// console.log(checkedLists);
		var selectHtml = '<div class="selects-container pull-right"><a class="icon-close pull-left" href="javascript:void(0);">×</a><div class="select-box pull-left select-72"><select class="design-select-box"><option>期間</option><option>1年</option><option>2年</option><option>3年</option><option>4年</option><option>5年</option><option>6年</option><option>7年</option><option>8年</option><option>9年</option><option>10年</option><option>11年以上</option></select></div></div>';
		var returnLists = $.map(
			checkedLists,function(value,index){
			return '<div class="checkedlist-inner"><div class="sortbtn pull-left"><a class="up pull-left" href="javascript:void(0);">&gt;</a><a class="down pull-left" href="javascript:void(0);">&gt;</a></div><div class="value pull-left">'+ value +'</div>'+ selectHtml+'</div>';
			}).join('');
		// var checkedListsSelects = $('<div class="select-box pull-left select-72"><select class="design-select-box"><option>選択</option></select></div>');
		$('.profile_trade-edit .inner-01 .cheked-lists').empty();
		$('.profile_trade-edit .inner-01 .cheked-lists').append(returnLists);
		$('.profile_trade-edit .inner-01 .cheked-lists .design-select-box').easySelectBox();
		//@entacl/////////////////////////////////////////////////////////////////
		/*$('.cheked-lists .checkedlist-inner a.pull-left').click(function(){
			var value = $(this).prev('.value').text();
			var val = $('.profile_trade-edit #modal-job-01 input:checked').val(value);
			$(val).attr("checked",false);


			$(this).parent().remove();
		});*/
		$('.profile_trade-edit .inner-01 .cheked-lists .selects-container > a.icon-close').click(function(){
			var value = $(this).parent().prev('.value').text();
			$('.profile_trade-edit #modal-job-01 input:checked').each(function() {
				if ($(this).val() == value) {
					$(this).attr("checked",false);
				}
			});


			$(this).parent().parent().remove();
			
			switchInner01Btn();
		});
		switchInner01Btn();
		//@entacl/////////////////////////////////////////////////////////////////
	});
	
	//@entacl/////////////////////////////////////////////////////////////////
	$(document).on("click", ".profile_trade-edit .inner-01 .checkedlist-inner .down", function(event) {
		$(this).parent().parent().next().after($(this).parent().parent());
		
		switchInner01Btn();
	});
	$(document).on("click", ".profile_trade-edit .inner-01 .checkedlist-inner .up", function(event) {
		$(this).parent().parent().prev().before($(this).parent().parent());
		
		switchInner01Btn();
	});
	function switchInner01Btn() {
		$(".profile_trade-edit .inner-01 .checkedlist-inner .down").css({visibility:"visible"});
		$(".profile_trade-edit .inner-01 .checkedlist-inner .up").css({visibility:"visible"});	
		$(".profile_trade-edit .inner-01 .checkedlist-inner .up:first").css({visibility:"hidden"});
		$(".profile_trade-edit .inner-01 .checkedlist-inner .down:last").css({visibility:"hidden"});
	}
	//@entacl/////////////////////////////////////////////////////////////////
})


$(function(){
	$('.profile_trade-edit #modal-job-02 .btn-main-color').click(function(event) {
		var checkedLists = [];
		$('.profile_trade-edit #modal-job-02 input:checked').each(function(){
			checkedLists.push($(this).val());
		});

		// console.log(checkedLists);
		var selectHtml = '<div class="selects-container pull-right"><a class="icon-close pull-left" href="javascript:void(0);">×</a><div class="select-box pull-left select-72"><select class="design-select-box"><option>期間</option><option>1年</option><option>2年</option><option>3年</option><option>4年</option><option>5年</option><option>6年</option><option>7年</option><option>8年</option><option>9年</option><option>10年</option><option>11年以上</option></select></div></div>';
		var returnLists = $.map(
			checkedLists,function(value,index){
			return '<div class="checkedlist-inner"><div class="sortbtn pull-left"><a class="up pull-left" href="javascript:void(0);">&gt;</a><a class="down pull-left" href="javascript:void(0);">&gt;</a></div><div class="value pull-left">'+ value +'</div>'+ selectHtml+'</div>';
			}).join('');
		// var checkedListsSelects = $('<div class="select-box pull-left select-72"><select class="design-select-box"><option>選択</option></select></div>');
		$('.profile_trade-edit .inner-02 .cheked-lists').empty();
		$('.profile_trade-edit .inner-02 .cheked-lists').append(returnLists);
		$('.profile_trade-edit .inner-02 .cheked-lists .design-select-box').easySelectBox();
		//@entacl/////////////////////////////////////////////////////////////////
		/*$('.cheked-lists .checkedlist-inner a.pull-left').click(function(){
			$(this).parent().remove();
		});*/
		$('.profile_trade-edit .inner-02 .cheked-lists .selects-container > a.icon-close').click(function(){
			var value = $(this).parent().prev('.value').text();
			$('.profile_trade-edit #modal-job-02 input:checked').each(function() {
				if ($(this).val() == value) {
					$(this).attr("checked",false);
				}
			});


			$(this).parent().parent().remove();
			
			switchInner02Btn();
		});
		switchInner02Btn();
		//@entacl/////////////////////////////////////////////////////////////////
	});
	
	//@entacl/////////////////////////////////////////////////////////////////
	$(document).on("click", ".profile_trade-edit .inner-02 .checkedlist-inner .down", function(event) {
		$(this).parent().parent().next().after($(this).parent().parent());
		
		switchInner02Btn();
	});
	$(document).on("click", ".profile_trade-edit .inner-02 .checkedlist-inner .up", function(event) {
		$(this).parent().parent().prev().before($(this).parent().parent());
		
		switchInner02Btn();
	});
	function switchInner02Btn() {
		$(".profile_trade-edit .inner-02 .checkedlist-inner .down").css({visibility:"visible"});
		$(".profile_trade-edit .inner-02 .checkedlist-inner .up").css({visibility:"visible"});	
		$(".profile_trade-edit .inner-02 .checkedlist-inner .up:first").css({visibility:"hidden"});
		$(".profile_trade-edit .inner-02 .checkedlist-inner .down:last").css({visibility:"hidden"});
	}
	//@entacl/////////////////////////////////////////////////////////////////
})





$(function(){
	$('.cheked-lists .checkedlist-inner a.pull-left').click(function(){
		$(this).parent().remove();
	});
});

// 学歴
$(function(){
	var $newblock = $('.profile_background-edit .newblock').clone(true);
	$(document).on('click','.profile_background-edit .add-btn',function(){
		$newblock.clone(true).insertBefore(this).show();
		$(this).prev('.newblock').find('.easy-select-box').remove();
		$(this).prev('.newblock').find('.design-select-box').easySelectBox();
	})
	$(document).on('click','.profile_background-edit .clear-btn', function(){
		$(this).parent().parent().parent().remove();
	});
})

// 語学レベル・資格
$(function(){
	var $newblock01 = $('.profile_level-edit .inner-01 .newblock').clone(true);
	var $newblock02 = $('.profile_level-edit .inner-02 .newblock').clone(true);
	//.inner-01
	$(document).on('click','.profile_level-edit .inner-01 .add-btn',function(){
		$newblock01.clone(true).insertBefore(this).show();
		$(this).prev('.newblock').find('.easy-select-box').remove();
		$(this).prev('.newblock').find('.design-select-box').easySelectBox();
	})
	//.inner-02
	$(document).on('click','.profile_level-edit .inner-02 .add-btn',function(){
		$newblock02.clone(true).insertBefore(this).show();
		$(this).prev('.newblock').find('.easy-select-box').remove();
		$(this).prev('.newblock').find('.design-select-box').easySelectBox();
	})
	//削除ボタン
	$(document).on('click','.profile_level-edit .clear-btn', function(){
		$(this).parent().parent().parent().remove();
	});
})

// 受賞歴
$(function(){
	var $newblock = $('.profile_receive-edit .newblock').clone(true);
	$(document).on('click','.profile_receive-edit .add-btn',function(){
		$newblock.clone(true).insertBefore(this).show();
		$(this).prev('.newblock').find('.easy-select-box').remove();
		$(this).prev('.newblock').find('.design-select-box').easySelectBox();
	})

	//削除ボタン
	$(document).on('click','.profile_receive-edit .clear-btn', function(){
		$(this).parent().parent().parent().parent().remove();
	});
})

// 出版物・掲載物
$(function(){
	var $newblock = $('.profile_publication-edit .newblock').clone(true);
	$(document).on('click','.profile_publication-edit .add-btn',function(){
		$newblock.clone(true).insertBefore(this).show();
		$(this).prev('.newblock').find('.easy-select-box').remove();
		$(this).prev('.newblock').find('.design-select-box').easySelectBox();
	})

	//削除ボタン
	$(document).on('click','.profile_publication-edit .clear-btn', function(){
		$(this).parent().parent().parent().parent().remove();
	});
})


/* ===============================================
設定ページ
=============================================== */
//ブロック企業追加
$(function(){
	$('.page-setting .setting-block .inner-content01 .block-btn').click(function(){
		var blockcp = $('.page-setting .setting-block .inner-content01 .block-name').val();
		$('.page-setting .setting-block .label-container').append('<div class="label label-main-color">'+'<div class="cpname">'+blockcp+'</div><a href="javascript:void(0);">×</a></div>')
	});
});

	$(document).on('click','.page-setting .setting-block .inner-content02 .label a', function(){
		$(this).parent().remove();
	});

//ブロックエージェント追加
	$(document).on('click','.page-setting .setting-block .agentlist .closebtn', function(){
		$(this).parent().remove();
	});


//通知設定
$(function(){
	$('.inner-02-01 .selectnum .select-push-scout-num .esb-item').on('click',function() {
		$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-new').not(':first-child').remove();
		var numhtml = $(this).html();
		var num = eval(numhtml);
		var i = 1;
		while (i < num) {
			$('.page-setting .setting-push .inner-02-01 .clone-contents .push-new:first-child').clone(true).appendTo('.page-setting .setting-push .inner-02-01 .clone-contents').show();
			$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-scout-num.push-new .easy-select-box').remove();
			$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-scout-num.push-new select').easySelectBox();
			i++;
		}
	});
})

$(function(){
	$('.inner-02-02 .selectnum .select-push-message-num .esb-item').on('click',function() {
		var numhtml = $(this).html();
		var num = eval(numhtml);
		var i = 1;
		while (i < num) {
			$('.page-setting .setting-push .inner-02-02 .clone-contents .push-new:first-child').clone(true).appendTo('.page-setting .setting-push .inner-02-02 .clone-contents').show();
			$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-message-num.push-new .easy-select-box').remove();
			$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-message-num.push-new select').easySelectBox();
			i++;
		}
	});
})
$(function(){
	$('.inner-content03 .selectnum .select-push-fb-num .esb-item').on('click',function() {
		var numhtml = $(this).html();
		var num = eval(numhtml);
		var i = 1;
		while (i < num) {
			$('.page-setting .setting-push .inner-content03 .clone-contents .push-new:first-child').clone(true).appendTo('.page-setting .setting-push .inner-content03 .clone-contents').show();
			$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-fb-num.push-new .easy-select-box').remove();
			$(this).parent().parent().parent().parent().parent().parent().find('.clone-contents .push-fb-num.push-new select').easySelectBox();
			i++;
		}
	});
})



//エージェントピックアップ
$(function(){
	$('.page-setting #modal-setting-01 .right-block .btn').click(function(){
		var agentName = $(this).parent().prev('.left-block').find('.text-block').text();
		console.log(agentName);
		$('.page-setting .agent').empty();
		$('.page-setting .agent').append(agentName + '<a href="javascript:void(0);"> × </a>');
	});

	$('.page-setting .agent').click(function(){
		$('.page-setting .agent').empty();
	});
})


/* ===============================================
お知らせ
=============================================== */
$(function(){
	$('.page-oshirase .all-select input').click(function(){
		var items = $('.page-oshirase #accordion-oshirase').find('input');
		if($(this).is(':checked')) { 
			$(items).prop('checked', true); 
		} else { 
			$(items).prop('checked', false);
		};
	});
	$('.page-oshirase .all-select .btn').click(function(){
		var items = $('.page-oshirase #accordion-oshirase .panel input');
		if($(items).is(':checked')) { 
			$(items).next('a').removeClass('unread'); 
		};
	});
});


/* ===============================================
モーダル 
=============================================== */

$(function(){
		$('.checkbox-lists-container li').heightLine();
});


/* ===============================================
チュートリアル モーダル
=============================================== */

//チュートリアルデモ
$(function(){
	$('.page-index .job').eq(1).find('.submenu-like').click(function(event) {
		$('.tutorial-modal').modal();
	});
})

//チュートリアルデモ02
$(function(){
	$('.page-index .job').eq(2).find('.submenu-like').click(function(event) {
		$('.experience-modal').modal();
	});
})


//次へボタン
$(document).on('click','.tutorial-modal .btn-next' ,function(){
	$(this).parent().parent().parent().parent().parent().parent('.modal-content').hide();
	$(this).parent().parent().parent().parent().parent().parent('.modal-content').next('.modal-content').fadeIn();
});

//戻るボタン
$(document).on('click','.tutorial-modal .btn-prev' ,function(){
	$(this).parent().parent().parent().parent().parent().parent('.modal-content').hide();
	$(this).parent().parent().parent().parent().parent().parent('.modal-content').prev('.modal-content').fadeIn();
});

$(document).on('click','.tutorial-modal .step05 .btn-block .btn' ,function(){
	$(this).parent().parent().parent().parent().parent().parent('.modal-content').hide();
	$(this).parent().parent().parent().parent().parent().parent().parent().find('.modal-content.step01').fadeIn();
});

//ブロック企業追加
$(function(){
	$('.tutorial-modal .setting-block .inner-content01 .block-btn').click(function(){
		var blockcp = $('.tutorial-modal .setting-block .inner-content01 .block-name').val();
		$('.tutorial-modal .setting-block .label-container').append('<div class="label label-main-color">'+'<div class="cpname">'+blockcp+'</div><a href="javascript:void(0);">×</a></div>')
	});
});
$(document).on('click','.tutorial-modal .setting-block .inner-content02 .label a', function(){
	$(this).parent().remove();
});



/* ===============================================
チュートリアル モーダル
=============================================== */

$(function(){
	$(document).on('click','.experience-modal-job #modal-job-01 .btn-main-color',function(){
		var checkedLists = [];
		$('.experience-modal-job #modal-job-01 input:checked').each(function(){
			checkedLists.push($(this).val());
		});

		// console.log(checkedLists);
		var selectHtml = '<a class="icon-close pull-right" href="javascript:void(0);">×</a>';
		var returnLists = $.map(
			checkedLists,function(value,index){
			return '<div class="checkedlist-inner"><div class="value pull-left">'+ value +'</div>'+ selectHtml+'</div>';
			}).join('');
		// var checkedListsSelects = $('<div class="select-box pull-left select-72"><select class="design-select-box"><option>選択</option></select></div>');
		/*$('.experience-modal .inner-01 .cheked-lists').empty();
		$('.experience-modal .inner-01 .cheked-lists').append(returnLists);
		$('.experience-modal .inner-01 .cheked-lists .design-select-box').easySelectBox();*/
		$('.tutorial-modal .step02 .inner-01 .cheked-lists').empty();
		$('.tutorial-modal .step02 .inner-01 .cheked-lists').append(returnLists);
		$('.tutorial-modal .step02 .inner-01 .cheked-lists .design-select-box').easySelectBox();
	});
});

$(function(){
	$(document).on('click','.experience-modal-job #modal-job-02 .btn-main-color',function(){
		var checkedLists = [];
		$('.experience-modal-job #modal-job-02 input:checked').each(function(){
			checkedLists.push($(this).val());
		});

		// console.log(checkedLists);
		var selectHtml = '<a class="icon-close pull-right" href="javascript:void(0);">×</a>';
		var returnLists = $.map(
			checkedLists,function(value,index){
			return '<div class="checkedlist-inner"><div class="value pull-left">'+ value +'</div>'+ selectHtml+'</div>';
			}).join('');
		// var checkedListsSelects = $('<div class="select-box pull-left select-72"><select class="design-select-box"><option>選択</option></select></div>');
		/*$('.experience-modal .inner-02 .cheked-lists').empty();
		$('.experience-modal .inner-02 .cheked-lists').append(returnLists);
		$('.experience-modal .inner-02 .cheked-lists .design-select-box').easySelectBox();*/
		$('.tutorial-modal .step02 .inner-02 .cheked-lists').empty();
		$('.tutorial-modal .step02 .inner-02 .cheked-lists').append(returnLists);
		$('.tutorial-modal .step02 .inner-02 .cheked-lists .design-select-box').easySelectBox();
	});
})

$(function(){
	$(document).on("click", '.tutorial-modal .step02 .inner-01 .cheked-lists a.icon-close', function(){
		var value = $(this).prev().text();
		$('.experience-modal-job #modal-job-01 input:checked').each(function() {
			if ($(this).val() == value) {
				$(this).attr("checked",false);
			}
		});


		$(this).parent().remove();
	});
	$(document).on("click", '.tutorial-modal .step02 .inner-02 .cheked-lists a.icon-close', function(){
		var value = $(this).prev().text();
		$('.experience-modal-job #modal-job-02 input:checked').each(function() {
			if ($(this).val() == value) {
				$(this).attr("checked",false);
			}
		});

		$(this).parent().remove();
	});
});
/* ===============================================
ログイン モーダル
=============================================== */

//チュートリアルデモ
$(function(){
	$('.page-index .job').eq(3).find('.submenu-like').click(function(event) {
		$('.login-modal').modal();
	});
})

/* ===============================================
モーダル
=============================================== */





$(function() {
	// プレースホルダー
	$("textarea").each(function() {
		if ($(this).prev().hasClass("template")) {
			if ($(this).val() == $(this).prev().val()) {
				$(this).css({"color":"#999"});
			} else if ($(this).val() == "") {
				$(this).css({"color":"#999"});
				$(this).val($(this).prev().val());
			}
			
			$(this).focus(function() {
				if ($(this).val() == $(this).prev().val()) {
					$(this).css({"color":"#000"});
					$(this).val("");
				}
			}).blur(function() {
				if ($(this).val() == "") {
					$(this).css({"color":"#999"});
					$(this).val($(this).prev().val());
				}
			});
		}
	});
	
	
	setInterval(checkCount, 100);
	function checkCount() {
		// プレースホルダーを考慮した文字数チェック
		var $target = $(".profile_career-edit textarea").not(".template");
		var $template = $(".profile_career-edit textarea.template");
		var text = "<span>" + $target.val().length + "</span> / 2,000文字";
		if ($target.val() != $template.val()) $target.next().html(text);
		else $target.next().html("<span>0</span> / 2,000文字");
		
		$(".business-lists .cp-block-ui05 textarea").each(function() {
			var text = "<span>" + $(this).val().length + "</span> / 2,000文字";
			$(this).next().html(text);
		});
		
		$("#modal-job-sample textarea").each(function() {
			var text = "<span>" + $(this).val().length + "</span> / 2,000文字";
			$(this).next().html(text);
		});
	}
});
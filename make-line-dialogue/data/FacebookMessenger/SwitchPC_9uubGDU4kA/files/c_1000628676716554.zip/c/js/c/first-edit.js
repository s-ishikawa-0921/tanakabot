$(function(){
	$(document).on("click", ".first-body .remove-other a", function(event) {
		event.preventDefault();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().remove();
	});
	$(".first-body .add-other a").click(function() {
		var txtarea = 
'<h4 class="other-title">' + 
	'<input type="text" placeholder="その他（タイトルを変更する事ができます）">' + 
'</h4>' + 
'<p class="info-detail-text">' + 
	'<textarea></textarea>' + 
'</p>' + 
'<div class="text-count"><span>0</span> / 2,000文字</div>' + 
'<div class="other-photo clearfix">' + 
	'<div class="add-other-photo photo1">' + 
		'<div class="add-btn">' + 
			'<input type="file" class="input-file">' + 
			'<div class="add-btn-text"><span>画像を選択してください</span><br>推奨サイズ：240×180　最大5MB JPEG形式</div>' + 
		'</div>' + 
	'</div>' + 
	'<div class="add-other-photo photo2">' + 
		'<div class="add-btn">' + 
			'<input type="file" class="input-file">' + 
			'<div class="add-btn-text"><span>画像を選択してください</span><br>推奨サイズ：240×180　最大5MB JPEG形式</div>' + 
		'</div>' + 
	'</div>' + 
'</div>' + 
'<div class="remove-other"><a href="javascript:void(0);">その他情報を削除</a></div>';
		$(this).parent().before(txtarea);
	});
	
	setInterval(checkCount, 100);
	function checkCount() {
		$(".info-text textarea, .info-detail-text textarea, .form-other textarea").each(function(i) {
			var text = "<span>" + $(this).val().length + "</span> / 2,000文字";
			$(this).parent().next().html(text);
		});
	}
});


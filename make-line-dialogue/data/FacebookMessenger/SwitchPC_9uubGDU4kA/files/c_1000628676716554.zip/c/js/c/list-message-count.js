$(function(){
	setInterval(checkReplyCount, 100);
	function checkReplyCount() {
		if ($(".open").length == 1 && $(".open").parent().find(".reply-top textarea").length > 0) {
			var text = "<span>" + $(".open").parent().find(".reply-top textarea").val().length + "</span> / 2,000文字";
			$(".open").parent().find(".text-count").html(text);
		}
	}
});


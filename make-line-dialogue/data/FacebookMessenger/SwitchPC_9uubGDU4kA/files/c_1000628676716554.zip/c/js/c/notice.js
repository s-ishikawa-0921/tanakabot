$(function(){
	$(document).on("click", ".remove-address a", function(event) {
		event.preventDefault();
		$(this).parent().parent().parent().remove();
	});
	$(".add-address a").click(function() {
		var txtarea = 
'<div class="form-group clearfix">' + 
	'<div class="form-box">' + 
		'<div class="checkbox-container">' + 
			'<label class="control-label">通知先アドレス</label>' + 
			'<input type="text">' + 
		'</div>' + 
		'<div class="remove-address"><a href="javascript:void(0);">削除</a></div>' + 
	'</div>' + 
'</div>';
		$(this).parent().before(txtarea);
	});
});


$(function () {
	var scene = 1;
	var isAnimating = true;
	var scrollTopArray = [0, 0, 600, 0, 700, 800, 0, 900];
	
	$("#tutorial-layer").css({opacity:0});
	$(".turorial-box").each(function() {
		$(this).css({display:"none"});
		$(this).find(".tutorial-text-box").css({display:"none", opacity:0});
		$(this).find(".tutorial-pic").css({display:"none", opacity:0});
		
		//scrollTopArray.push($(this).find("フロート").offset().top);
	});
	
	$(document).on("click", ".btn-next", function(event) {
		event.preventDefault();
		
		if (!isAnimating) {
			changeScene();
			
			scene++;
		}
	});
	
	$(document).on("click", ".btn-back", function(event) {
		event.preventDefault();
		
		if (!isAnimating) {
			changeScene();
			
			scene--;
		}
	});
	
	$(".scene0" + scene + " .tutorial-pic").css({display:"block"});
	$(".scene0" + scene).css({display:"block"});
	$(".scene0" + scene + " .tutorial-text-box").css({display:"block"});
	$("#tutorial-layer").delay(100).animate({opacity:0.8}, 300);
	$(".scene0" + scene + " .tutorial-pic").delay(100).animate({opacity:1}, 300);
	$(".scene0" + scene + " .tutorial-text-box").delay(300).animate({opacity:1}, 300, function() {
		isAnimating = false;
	});
	
	function changeScene() {
		isAnimating = true;
		$(".scene0" + scene).animate({opacity:0}, 300, function() {
			$(this).find(".tutorial-pic").css({display:"none", opacity:0});
			$(this).find(".tutorial-text-box").css({display:"none", opacity:0});
			
			$(this).css({display:"none"});
			$("body, html").animate({scrollTop: scrollTopArray[scene - 1]}, 300, function() {
				$(".scene0" + scene + " .tutorial-pic").css({display:"block"});
				$(".scene0" + scene).css({display:"block", opacity:1});
				$(".scene0" + scene + " .tutorial-text-box").css({display:"block"});
				$(".scene0" + scene + " .tutorial-pic").delay(200).animate({opacity:1}, 300);
				$(".scene0" + scene + " .tutorial-text-box").delay(300).animate({opacity:1}, 300, function() {
					isAnimating = false;
				});
			});
		});
	}
});
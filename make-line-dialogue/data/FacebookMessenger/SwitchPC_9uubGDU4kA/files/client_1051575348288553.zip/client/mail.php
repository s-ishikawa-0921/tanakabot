<?php
	
	// Ajaxから渡ってきた各値を分かりやすいように格納
	$companyname = htmlspecialchars($_POST['companyname'], ENT_QUOTES, 'UTF-8');
	$tantoname = htmlspecialchars($_POST['tantoname'], ENT_QUOTES, 'UTF-8');
	$mailaddress = htmlspecialchars($_POST['mailaddress'], ENT_QUOTES, 'UTF-8');
	$tell = htmlspecialchars($_POST['tell'], ENT_QUOTES, 'UTF-8');
	$memo = htmlspecialchars($_POST['memo'], ENT_QUOTES, 'UTF-8');

	$errflg = '0';
    
	// 入力エラーチェック
	$error_massage = array();
		// 名前が未入力
		if(empty($companyname)) :
			$error_massage['companyname'] = '貴社名が入力されていません。';
			$errflg = "1";
		endif;
	    if(empty($tantoname)) :
			$error_massage['tantoname'] = 'ご担当者名が入力されていません。';
			$errflg = '1';
		endif;
		// メールアドレスが未入力
		if(empty($mailaddress)) :
			$error_massage['mailaddress'] = 'メールアドレスが入力されていません。';
			$errflg = '1';
		// メールアドレスの形式チェック
		elseif(!filter_var($mailaddress, FILTER_VALIDATE_EMAIL)) :
			$error_massage['mailaddress'] = 'メールアドレスの形式が正しくありません。';
			$errflg = '1';
		endif;
		// 本文が未入力
		if(empty($memo)) :
			$error_massage['memo'] = 'お問い合わせ内容が入力されていません。';
			$errflg = '1';
		endif;
 
	if($errflg=='0') :
		$str = '貴社名：'.$companyname . "\r\n";
		$str .= 'ご担当者名：'.$tantoname . "\r\n";
		$str .= 'メールアドレス：'.$mailaddress . "\r\n";
		$str .= '電話番号：'.$tell . "\r\n";
		$str .= 'お問い合わせ内容：'.$memo . "\r\n";
		$to='nobuyuki.arai@careritz.co.jp';
		$subject='企業からの問い合わせ:'.$companyname;
		$headers = 'From: 企業からの問い合わせ <nobuyuki.arai@careritz.co.jp>' . "\r\n";
		mail($to,$subject,$str,$headers);
	else :
		echo $error_massage['companyname'];
		echo $error_massage['tantoname'];
		echo $error_massage['mailaddress'];
		echo $error_massage['memo'];
	endif;
?>

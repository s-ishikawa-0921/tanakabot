var itemWidth, rightMax;

$(function(){
  columnfix();
  sliderSet();
  slideMove();
  setBtn();
});

function sliderSet() {
  var itemLength = $(".main-slider-wrap ul").length;
  itemWidth = $(".main-slider-wrap ul").width();
  $(".main-slider-inr").width(itemWidth * itemLength);
  rightMax = $(".main-slider-wrap").width() - $(".main-slider-inr").width();
}

function columnfix(){
  if($(".fixH").length > 0){
    $(".fixH").each(function(){
      var fixH = 0;
      var fixTarget = $(this).children("ul");
      fixTarget.each(function(){
        if($(this).height() > fixH) fixH = $(this).height();
      });
      fixTarget.height(fixH);
    });
  }
}

function slideMove() {
  sliderSet();
  $(".main-slider-btn li:first-child a").click(function() {
    leftMove = (parseInt($(".main-slider-inr").css("left"),10) + itemWidth > 0)? 0 : parseInt($(".main-slider-inr").css("left")) + itemWidth;
    $(".main-slider-inr").animate({
      "left": leftMove
    }, 500,function() {
      setBtn();
    });
    return false;
  });
  
  $(".main-slider-btn li:nth-child(2) a").click(function() {
    rightMove = (parseInt($(".main-slider-inr").css("left"),10) - itemWidth < rightMax)? rightMax: parseInt($(".main-slider-inr").css("left")) - itemWidth;
    $(".main-slider-inr").animate({
      "left": rightMove
    }, 500,function() {
      setBtn();
    });
    return false;
  });
  
}

function setBtn() {
  sliderSet();
  var Btn01 = $(".main-slider-btn li:first-child");
  var Btn02 = $(".main-slider-btn li:nth-child(2)");
  if( parseInt($(".main-slider-inr").css("left"),10) == 0 ) {
    Btn01.addClass("is-passive");
  } else {
    Btn01.removeClass("is-passive");
  }
  
  if( parseInt($(".main-slider-inr").css("left"),10) == rightMax ) {
    Btn02.addClass("is-passive");
  } else {
    Btn02.removeClass("is-passive");
  }
}
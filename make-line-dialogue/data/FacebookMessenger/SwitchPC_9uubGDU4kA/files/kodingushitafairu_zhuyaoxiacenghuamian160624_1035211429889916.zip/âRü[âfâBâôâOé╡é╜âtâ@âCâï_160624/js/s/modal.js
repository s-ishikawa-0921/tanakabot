$(function(){
  $('a[href^="#"]').not("#page-top a").click(function(){
    var elmID = ($(this).attr("href")) ? $(this).attr("href") : "#wrapper";
    if($(elmID).size()){
      posi = $(elmID).offset().top;
      $("html,body").animate({
        scrollTop: posi
      }, 500);
      return false;
    }
  });
  
  
  $(".good-btn a").not(".check a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $(".modal-contents.job").css("z-index",1001);
      $("#modal-overlay").fadeIn(500);
    }
    $(".modal-contents.good").fadeIn(500);
    return false;
  });
  
  $(".main-pick-up-list-detail .main-pick-up-dust a, .btn-gray.ico-dust a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.not-like").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  $(".main-pick-up-list-detail-inr >a, .message-chat-title a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.job").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  
  
  $("#modal-overlay, .modal-close a, .modal-contents.job .modal-close-btn a, .modal-close-text a, .modal-contents.not-like .btn-orange a, .modal-contents.more .btn-modal-close a,.modal-contents.later .btn-orange a").click(function() {
	if($(this).closest("p,div").hasClass("modal-over-close") && $(".modal-contents.job").css("display") === "block"){
		$(this).closest(".modal-contents").fadeOut(500);
		$(".modal-contents.job").css("z-index",1001);
	}else{
		$("#modal-overlay").fadeOut(500);
		$(".modal-contents").fadeOut(500);
		$("body").removeClass("modal-open");
		$(".modal-contents.job").css("z-index",1001);
		return false;
	}
  });
  

  
  $(".modal-contents.job .main-pick-up-dust a").click(function() {
    if( $(".modal-contents.good").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",1001);
    } else {
      $(".modal-contents.job").css("z-index",999);
    }
    $(".modal-contents.not-like").fadeIn(500);
  });
  
  $(".modal-contents.good .btn-orange a").click(function() {
    $(this).closest(".modal-contents").fadeOut(500);
    $(".modal-contents.more").fadeIn(500);
    return false;
  });
  
  
  $(".modal-contents.good .btn-modal-close a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",1001);
    } else {
      $(".modal-contents").fadeOut(500);
      $("#modal-overlay").fadeOut(500);
    }
    return false;
  });
  
  
  $(".ico-good a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $(".modal-contents.job").css("z-index",1001);
      $("#modal-overlay").fadeIn(500);
    }
    $(".modal-contents.near-matching").fadeIn(500);
  });

  
  $(".modal-contents.near-matching .btn-orange a").click(function() {
    $(this).closest(".modal-contents").fadeOut(500);
    $(".modal-contents.matching").fadeIn(500);
  });
  
  $(".btn-list02 li a").click(function() {
    var num = $(this).closest("li").index();
    $(this).closest(".modal-more-detail").hide();
    $(".modal-tab01 .modal-tab01-detail").eq(num).show();
    return false;
  });
  
  $(".modal-tab01 .modal-tab01-detail .btn-orange a").click(function() {
    var num = $(this).closest(".modal-tab01-detail").index();
    $(this).closest(".modal-tab01-detail").hide();
    $(".modal-more-detail").show();
    $(".btn-list02 li").eq(num).addClass("checked");
    return false;
  });
  
  $(".tab-list li a").click(function() {
    var num = $(this).closest("li").index();
    $(".tab-list li").removeClass("is-active");
    $(this).closest("li").addClass("is-active");
    $(".tab-wrap .tab-detail").hide();
    $(".tab-wrap .tab-detail").removeClass("is-active");
    $(".tab-wrap .tab-detail").eq(num).show();
    $(".tab-wrap .tab-detail").eq(num).addClass("is-active");
    return false;
  });
  
  $(".ico-later a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $(".modal-contents.job").css("z-index",1001);
      $("#modal-overlay").fadeIn(500);
    }
    
    $(".modal-contents.later").fadeIn(500);
    
  });
  
  $(".modal-contents.later .btn-orange a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.later").fadeOut(500);
      $(".modal-contents.job").css("z-index",1001);
    } else {
      $("#modal-overlay").fadeOut(500);
      $(".modal-contents").fadeOut(500);
      $("body").removeClass("modal-open");
    }
  });
  
  
  $(".message-temp a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.responce").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  $(".sample-list01 a").click(function() {
    $(".modal-contents.responce").fadeOut(500);
    $(".modal-contents.sample").fadeIn(500);
    
  });
  
  $(".modal-contents.sample .btn-orange a").click(function() {
    var text = $(this).closest(".modal-sample-text").find(".sample-message").text();
    $(".message-chat-input textarea").val();
    $(".message-chat-input textarea").val(text);
    $("#modal-overlay").fadeOut(500);
    $(".modal-contents").fadeOut(500);
    $("body").removeClass("modal-open");
  });

  //#リンクは無効
  $('a[href="#"]').click(function(){
    return false;
  });
});



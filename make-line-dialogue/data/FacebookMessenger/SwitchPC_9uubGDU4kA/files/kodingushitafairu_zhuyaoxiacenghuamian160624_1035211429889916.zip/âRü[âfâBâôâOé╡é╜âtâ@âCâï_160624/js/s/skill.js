$(function() {
	$( "#sortable" ).sortable({placeholder: 'ui-state-highlight', forcePlaceholderSize:true});
	$( "#sortable" ).disableSelection();
	
	$(".inner-02 input[type='button']").click(function() {
		var div = 
'<div style="float:left" class="ui-sortable-handle">' + 
	'<div class="skill-pickup">' + 
		'<span class="label label-main-color">' + $(this).prev().val() + '<a href="javascript:void(0);" class="delete-skill">×</a></span>' + 
	'</div>' + 
'</div>';
		$("#sortable").append(div);
	});
	$(document).on("click", ".profile_skill-edit .inner-01 .add-skill", function() {
		var div = 
'<div style="float:left" class="ui-sortable-handle">' + 
	'<div class="skill-pickup">' + 
		'<span class="label label-main-color">' + $(this).prev().html() + '</span>' + 
	'</div>' + 
'</div>';
		$("#sortable").append(div);
		$(this).parent().parent().remove();
	});
	$(document).on("click", "#sortable a", function() {
		$(this).parent().parent().parent().remove();
	});
	$(document).on("click", ".profile_skill-edit .inner-01 .delete-skill", function() {
		$(this).parent().parent().remove();
	});
});

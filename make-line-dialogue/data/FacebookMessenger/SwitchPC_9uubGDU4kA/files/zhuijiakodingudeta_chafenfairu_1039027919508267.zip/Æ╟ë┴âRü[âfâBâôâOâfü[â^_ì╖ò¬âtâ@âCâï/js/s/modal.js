$(function(){
  $('a[href^="#"]').not("#page-top a").click(function(){
    var elmID = ($(this).attr("href")) ? $(this).attr("href") : "#wrapper";
    if($(elmID).size()){
      posi = $(elmID).offset().top;
      $("html,body").animate({
        scrollTop: posi
      }, 500);
      return false;
    }
  });
  
  
  $(".good-btn a").not(".check a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $(".modal-contents.job").css("z-index",1001);
      $("#modal-overlay").fadeIn(500);
    }
    $(".modal-contents.more").fadeIn(500);
    return false;
  });
  
  $(".main-pick-up-list-detail .main-pick-up-dust a, .btn-gray.ico-dust a").click(function() {
    $("#modal-overlay").fadeIn(500);
    if($(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $(".modal-contents.job").css("z-index",1001);
    }
    $(".modal-contents.not-like").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  $(".main-pick-up-list-detail-inr >a, .message-chat-title a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.job").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  
  
  $(".modal-close a, .modal-contents.job .modal-close-btn a, .modal-close-text a, .modal-contents.not-like .btn-orange a,.btn-modal-close a,.modal-contents.later .btn-orange a, .modal-contents.good .btn-orange a").click(function() {
    if($(this).closest("p,div").hasClass("modal-over-close") && $(".modal-contents.job").css("display") === "block" ){
      $(this).closest(".modal-contents").fadeOut(500);
      $(".modal-contents.job").css("z-index",1001);
      

    } else if( $(this).closest("p,div").hasClass("modal-over-close") && $(".modal-contents.hint-list").css("display") === "block" ) {
      $(this).closest(".modal-contents").fadeOut(500);
      $(".modal-contents.hint-list").css("z-index",1001);
      if($(".modal-contents.hint01").css("display") === "none") {
        $("#modal-overlay").fadeOut(500);
        $("body").removeClass("modal-open");
      }
    } else{
      $("#modal-overlay").fadeOut(500);
      $(".modal-contents").fadeOut(500);
      $("body").removeClass("modal-open");
      $(".modal-contents.job").css("z-index",1001);
      return false;
    }
  });
  
  
  
  $("#modal-overlay").click(function() {
    if($(".modal-contents.job").css("display") == "block") {
      if( $(".modal-contents.more").css("display") == "block" || $(".modal-contents.good").css("display") == "block" || $(".modal-contents.near-matching").css("display") == "block" || $(".modal-contents.matching").css("display") == "block" || $(".modal-contents.not-like").css("display") == "block" )  {
        $("#modal-overlay").css("display","block");
        $(".modal-contents.job").css("display","block");
      } else {
        $("#modal-overlay").fadeOut(500);
        $(".modal-contents.job").fadeOut(500);
        $("body").removeClass("modal-open");
      }
    }
    if($(".modal-contents.hint01").css("display") == "block") {
      if($(".modal-contents.hint-list").css("display") == "block") {
        $(".modal-contents.hint01").fadeOut(500);
        $(".modal-contents.hint-list").css("z-index",1001);
      } else {
        $("#modal-overlay").fadeOut(500);
        $(".modal-contents").fadeOut(500);
        $("body").removeClass("modal-open");
      }
    }
    
    if($(".modal-contents.hint-list").css("display") == "block") {
      if($(".modal-contents.hint01").css("display") == "none") {
        $(".modal-contents").fadeOut(500);
        $("#modal-overlay").fadeOut(500);
        $("body").removeClass("modal-open");
      }
    }
  });
  

  
  $(".modal-contents.job .main-pick-up-dust a").click(function() {
    if( $(".modal-contents.good").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",1001);
    } else {
      $(".modal-contents.job").css("z-index",999);
    }
    $(".modal-contents.not-like").fadeIn(500);
  });
  
  $(".modal-contents.more .modal-more-detail>.btn-orange a").click(function() {
    $(this).closest(".modal-contents").fadeOut(500);
    $(".modal-contents.good").fadeIn(500);
    return false;
  });
  
  
  $(".modal-contents.good .btn-modal-close a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",1001);
    } else {
      $(".modal-contents").fadeOut(500);
      $("#modal-overlay").fadeOut(500);
    }
    return false;
  });
  
  
  $(".ico-good a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $("body").addClass("modal-open");
      $(".modal-contents.job").css("z-index",1001);
      $("#modal-overlay").fadeIn(500);
    }
    $(".modal-contents.near-matching").fadeIn(500);
    return false;
  });

  
  $(".modal-contents.near-matching .btn-orange a").click(function() {
    $(this).closest(".modal-contents").fadeOut(500);
    $(".modal-contents.matching").fadeIn(500);
    return false;
  });
  
  $(".btn-list02 li a").click(function() {
    var num = $(this).closest("li").index();
    $(this).closest(".modal-more-detail").hide();
    $(".modal-tab01 .modal-tab01-detail").eq(num).show();
    return false;
  });
  
  $(".modal-tab01 .modal-tab01-detail .btn-orange a").click(function() {
    var num = $(this).closest(".modal-tab01-detail").index();
    $(this).closest(".modal-tab01-detail").hide();
    $(".modal-more-detail").show();
    $(".btn-list02 li").eq(num).addClass("checked");
    return false;
  });
  
  $(".tab-list li a").click(function() {
    var num = $(this).closest("li").index();
    $(".tab-list li").removeClass("is-active");
    $(this).closest("li").addClass("is-active");
    $(".tab-wrap .tab-detail").hide();
    $(".tab-wrap .tab-detail").removeClass("is-active");
    $(".tab-wrap .tab-detail").eq(num).show();
    $(".tab-wrap .tab-detail").eq(num).addClass("is-active");
    return false;
  });
  
  $(".ico-later a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.job").css("z-index",999);
    } else {
      $(".modal-contents.job").css("z-index",1001);
      $("#modal-overlay").fadeIn(500);
      $("body").addClass("modal-open");
    }
    
    $(".modal-contents.later").fadeIn(500);
    return false;
  });
  
  $(".modal-contents.later .btn-orange a").click(function() {
    if( $(".modal-contents.job").css("display") == "block" ) {
      $(".modal-contents.later").fadeOut(500);
      $(".modal-contents.job").css("z-index",1001);
    } else {
      $("#modal-overlay").fadeOut(500);
      $(".modal-contents").fadeOut(500);
      $("body").removeClass("modal-open");
    }
    return false;
  });
  
  
  $(".message-temp a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.responce").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  $(".sample-list01 a").click(function() {
    $(".modal-contents.responce").fadeOut(500);
    $(".modal-contents.sample").fadeIn(500);
    return false;
  });
  
  $(".modal-contents.sample .btn-orange a").click(function() {
    var text = $(this).closest(".modal-sample-text").find(".sample-message").text();
    $(".message-chat-input textarea").val();
    $(".message-chat-input textarea").val(text);
    $("#modal-overlay").fadeOut(500);
    $(".modal-contents").fadeOut(500);
    $("body").removeClass("modal-open");
    return false;
  });
  
  $(".modal-on-hint-list a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.hint-list").css("z-index",1001);
    $(".modal-contents.hint-list").fadeIn(500);
    $("body").addClass("modal-open");
    return false;
  });
  
  $(".hint-key li a").click(function() {
    $(this).closest(".modal-contents").css("z-index",999);
    $(".modal-contents.hint01").fadeIn(500);
    modalActiveNum = 1;
    $(".active-num").text(modalActiveNum);
    $(".hint-slider-inr").css("left", 0);
    num = 0;
    modalsetBtn();
    $(".hint-slider-pointer ul").find("li").removeClass("is-active");
    $(".hint-slider-pointer ul").find("li").eq(num).addClass("is-active");
    return false;
  });

  //#リンクは無効
  $('a[href="#"]').click(function(){
    return false;
  });
});


//modal-slider

$(function(){
  modalSlideNum = $(".hint-slider-detail").length;
  modalSlideItem = $(".hint-slider-detail").width();
  modalActiveNum = 1;
  $(".length-num").text(modalSlideNum);
  modalSlideFlame = $(".hint-slider-detail").css("width", modalSlideItem + "px");
  $(".hint-slider-inr").css("width", modalSlideItem * modalSlideNum + "px");
  modalrightMax = modalSlideItem - $(".hint-slider-inr").width();
  
  if( $(".modal-contents.hint01").length) {
    modalsliderSet();
    //pointer
    $(".hint-slider-pointer ul").html("");
    for (var i = 0; i < modalSlideNum; i++) {
      $(".hint-slider-pointer ul").append('<li><a href="#"></a></li>');
    }
  }

 
  $(".card-list dl + p a").click(function() {
    $("#modal-overlay").fadeIn(500);
    $(".modal-contents.hint01").fadeIn(500);
    $("body").addClass("modal-open");
    modalActiveNum = 1;
    $(".active-num").text(modalActiveNum);
    $(".hint-slider-inr").css("left", 0);
    modalsetBtn();
    num = 0;
    $(".hint-slider-pointer ul").find("li").removeClass("is-active");
    $(".hint-slider-pointer ul").find("li").eq(num).addClass("is-active");
  });

  $(".hint-slider-pointer li a").click(function() {
    var pointerIndex =$(".hint-slider-pointer li a").index($(this));
    $(".hint-slider-pointer li").removeClass("is-active");
    $(this).closest("li").addClass("is-active");
    $(".hint-slider-inr").animate({
      "left": modalSlideItem * -pointerIndex
    }, 500,function() {
      modalsetBtn();
      modalActiveNum = pointerIndex + 1;
      num = pointerIndex;
      $(".active-num").text(pointerIndex + 1);
    });
  });
});

function modalsliderSet() {
  modalsetBtn();
  modalslideMove();
}




function modalslideMove() {
  $(".hint-slider-btn li:first-child a").click(function() {
  	 if(!$(this).closest("li").hasClass("is-passive")){
       $(".hint-slider-pointer ul").find("li").removeClass("is-active");
       num--;
       $(".hint-slider-pointer ul").find("li").eq(num).addClass("is-active");
        modalActiveNum--;
        if( 0 == modalActiveNum ) {
          $(".active-num").text(1);
        } else {
          $(".active-num").text(modalActiveNum);
        }
      
        var modalleftMove = (parseInt($(".hint-slider-inr").css("left"),10) + modalSlideItem > 0)? 0 : parseInt($(".hint-slider-inr").css("left")) + modalSlideItem;
        $(".hint-slider-inr").animate({
          "left": modalleftMove
        }, 500,function() {
          modalsetBtn();
        
       });
     }
     return false;
  });
  
  $(".hint-slider-btn li:nth-child(2) a").click(function() {
  	if(!$(this).closest("li").hasClass("is-passive")){
      $(".hint-slider-pointer ul").find("li").removeClass("is-active");
      num++;
      $(".hint-slider-pointer ul").find("li").eq(num).addClass("is-active");
      modalActiveNum++;
      if( modalSlideNum >= modalActiveNum ) $(".active-num").text(modalActiveNum);
      
      var modalrightMove = (parseInt($(".hint-slider-inr").css("left"),10) - modalSlideItem < modalrightMax)? modalrightMax: parseInt($(".hint-slider-inr").css("left")) - modalSlideItem;
      $(".hint-slider-inr").animate({
        "left": modalrightMove
      }, 500,function() {
        modalsetBtn();
      });
    }
    return false;
  });
}


function modalsetBtn() {
  sliderSet();
  var Btn01 = $(".hint-slider-btn li:first-child");
  var Btn02 = $(".hint-slider-btn li:nth-child(2)");
  if( parseInt($(".hint-slider-inr").css("left"),10) == 0 ) {
    Btn01.addClass("is-passive");
  } else {
    Btn01.removeClass("is-passive");
  }
  
  if( parseInt($(".hint-slider-inr").css("left"),10) == modalrightMax ) {
    Btn02.addClass("is-passive");
  } else {
    Btn02.removeClass("is-passive");
  }
}


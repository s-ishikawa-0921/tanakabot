package net.npaka.textviewex;
import android.R;
import android.app.Activity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.LinearLayout;

import java.text.DecimalFormat;
import java.util.concurrent.atomic.AtomicInteger;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Vibrator;


//テキストビューとイメージビュー
public class TextViewEx extends Activity {
	
	private Context mContext ;
	private MySurfaceView mSurfaceView;
	private long mPeriod = -1 ;
	
	private Vibrator vib;
	private double cm;
	
	
	// プログラム起動時からマイクからの入力の積算値
	public volatile int mRawGeigerCount;
	// スレッド停止用の変数
	boolean isEnd = false;
	// 過去の一定時間のカウント数
	int mSumOfCountInHistry = 0;
	// 起動から一定時間経って、有効なデータが出ているかどうか
	boolean mIsEffectiveData = false;

	short mDebugSoundMax = 300;
	short mDebugSoundMin = 300 ;
	volatile int mDetectOnPeriod = 0 ;

	
    //アクティビティ起動時に呼ばれる
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        vib = (Vibrator)getSystemService(VIBRATOR_SERVICE);
    	
		super.onCreate(savedInstanceState);

		mSurfaceView = new MySurfaceView(this);
		setContentView(mSurfaceView);
		
    }  
    
	@Override
	public void onStart() {
		super.onStart();
	}
	@Override
	public void onRestart() {
		super.onRestart();
	}
	@Override
	public void onResume() {
		super.onResume();
	}
	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onStop() {
		super.onStop();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		isEnd = true;
	}
	
	
	class MySurfaceView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
		//Bitmap backGround ;
		Thread mThread ;
		static final int HISTORY_MAX = 120;
		int mStartupCountDown = HISTORY_MAX;
		static final int MEASURE_SEC = 60 ;

		int[] mHistry = new int[HISTORY_MAX];
		int mHistryPtr = 0;
		boolean isDestryOccur = false ;

		public MySurfaceView(Context context) {
			super(context);
			mContext = context ;
			getHolder().addCallback(this);

			// Threadを起動する
			mThread = new Thread(this);
			mThread.setDaemon(true);
			mThread.start();

		}

		@Override
		public void run() {
			//backGround = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.background); 

			
			SoundDetect mGeigerDetect = new SoundDetect();
			//mGeigerDetect.setDaemon(true);
			mGeigerDetect.start();

			DetectThreshold mDetectThreshold = new DetectThreshold();
			mDetectThreshold.setDaemon(true);
			mDetectThreshold.start();
			
			//OnOffDetect mOnOffDetect = new OnOffDetect();
			//mOnOffDetect.setDaemon(true);
			//mOnOffDetect.start();
			
			//Vibrator vib = (Vibrator)getSystemService(VIBRATOR_SERVICE);
			//vib.vibrate(5000);
			
			
			while (!isEnd) {
				Canvas canvas = getHolder().lockCanvas();
				if (canvas != null) {
					mSurfaceView.doDraw(canvas, mSumOfCountInHistry++);
					getHolder().unlockCanvasAndPost(canvas);
				}
				//vib.vibrate(50);
				if(cm < 200){
					vib.vibrate((long)(100-cm/2));
				}
				SleepMs(100);
			}
		}

		void doDraw(Canvas canvas, int count) {
			Paint paint = new Paint();
			//Log.d("TEST", "doDraw");

			canvas.drawColor(Color.WHITE);

			paint.setColor(Color.BLACK);
			paint.setAntiAlias(true);
			paint.setTextSize(40);
			int offsetX = 40 ;
			int offsetY = 80 ;

			canvas.drawText("MaxSound: " + mDebugSoundMax , 0+offsetX, 240+offsetY, paint);
			canvas.drawText("MinSound: " + mDebugSoundMin , 0+offsetX, 280+offsetY, paint);
			canvas.drawText("mDetectOnPeriod: " + mDetectOnPeriod , 0+offsetX, 320+offsetY, paint);//mDebugSoundMin
			canvas.drawText("detectPlusThreshold="  + detectPlusThreshold , 0+offsetX, 360+offsetY, paint);
			cm = (double )mDetectOnPeriod / ( 44100.0 ) * 1000 * 10 *2;
			canvas.drawText("" + ( (int )cm ) + "cm", 0+offsetX, 400+offsetY, paint);//mDebugSoundMin 
			
			paint.setTextSize(30);//mDetectOnPeriod
			//canvas.drawText("株式会社シーエー"+count, 0 + offsetX, 480 + offsetY, paint);
		}
		@Override
		public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
			Log.d("TEST", "surfaceChanged");
		}

		@Override
		public void surfaceCreated(SurfaceHolder holder) {
		}

		@Override
		public void surfaceDestroyed(SurfaceHolder holder) {
			Log.d("TEST", "surfaceDestroyed");
		}

		int incrimentHistryPtr(int ptr) {
			ptr++;
			if (ptr >= mHistry.length) {
				ptr = 0;
			}
			return ptr;
		}
	}

	//音声の有り無しを判定するスレッショルドを動的に変更するスレッド
	volatile int detectPlusThreshold = 20000;//仮のスレッショルド
	volatile int detectMinuxThreshold = - detectPlusThreshold ;
	volatile int maxAdValue = Short.MIN_VALUE ;
	volatile int minAdValue = Short.MAX_VALUE ;
	class DetectThreshold extends Thread {
		@Override
		public void run() {
			int max, min ;
			SleepMs(1000);
			while(true) {
				min = minAdValue ;
				max = maxAdValue ;
				if( ( max > 20000) && ( min < -20000 ) ) {
					detectPlusThreshold = ( ( max * 2 ) / 3 ); // 2/3 の値を threshold とする
					detectMinuxThreshold = - detectPlusThreshold ;
				}
				//Log.d("","thrs="+detectPlusThreshold);
				SleepMs(500);
			}
		}
	}

	//音声データを取り込み、音声が連続して検出される時間を求めるスレッド
	class SoundDetect extends Thread {
		private static final int SAMPLE_RATE = 44100;

		int bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT);
		AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, AudioFormat.CHANNEL_CONFIGURATION_MONO,
				AudioFormat.ENCODING_PCM_16BIT, bufferSize * 4);
		short[] buffer = new short[bufferSize];

		@Override
		public void run() {
			final long dbgClearSoundMaxCnt = SAMPLE_RATE / 4 ;
			long dbgTotalDataCnt = 0 ;
			final int stabilyzePeriod = SAMPLE_RATE / 500 ;
	    	detectPlusThreshold = 20000;//音の大きさ
	    	detectMinuxThreshold = - detectPlusThreshold ;
			long targetSample = 0; //何番目のサンプリング
			long onTime = 0 ;
			int offCount = 0 ;
			boolean inSoundDetect = false ;

			int i ; 
			short value;// 動的に作りたくないのでここに置く(意味ないかも)
			
			android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
			int readCount ;
			audioRecord.startRecording();
			
			
			while (!isEnd) {
				//Log.d("SOUND",".");
				readCount = audioRecord.read(buffer, 0, bufferSize);
				for (i = 0; i < readCount; i++) {
					
					value = fir( buffer[i] ) ; 
					
                	//以下はデバッグ用。音声データの max/min を求める
					if( value < minAdValue ) {
						minAdValue = value ;
						mDebugSoundMin = (short )minAdValue ;
					}
					if( value > maxAdValue ) {
						maxAdValue = value ;
						mDebugSoundMax = (short )maxAdValue ;
					}
	                dbgTotalDataCnt ++ ;
	                if( dbgTotalDataCnt >= dbgClearSoundMaxCnt ) {
	                	//System.out.println("max="+dbgMaxAd+"min="+dbgMinAd);
	                	dbgTotalDataCnt = 0 ;
	                	minAdValue = Short.MAX_VALUE ;
	                	maxAdValue = Short.MIN_VALUE ;
	                }
	                //ここまでデバッグ用

					if( ( detectMinuxThreshold < value ) && ( value < detectPlusThreshold) ){//音声が off ?
						if( inSoundDetect ) {
							offCount ++ ;
							if( offCount > stabilyzePeriod ) {//十分長い時間、off になっているか?
								offCount = 0 ;
								mDetectOnPeriod = ( int )( targetSample - onTime );
								//Log.d(getName(), "off "+onTime + "->" + targetSample + " " + mDetectOnPeriod);
								mDetectOnPeriod -= stabilyzePeriod ;
								inSoundDetect = false ;
							}
						}
					}
					else {//音声が on ?
						offCount = 0 ;
						if( inSoundDetect == false ) {
							//Log.d(getName(), "on");
							offCount = 0 ;
							inSoundDetect = true ;
							targetSample = 0 ;
							onTime = targetSample ;
						}
					}
					targetSample ++ ;
				}
				SleepMs(1);
				//Log.d(getName(), "loop");
			}
			audioRecord.stop();
			audioRecord.release();
			
		}

	}
	
    
	// Sleep
	void SleepMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}
	
	
	static final double firCoef[] = {
		-0.00033972385976285,-0.0030369939922087,-0.0082149644417353,-0.015365062783593,
		-0.023736742584556,-0.032422198032309,-0.040461447217688,-0.046955100447607,-0.051171003770232,
		0.94736842105263,
		-0.051171003770232,-0.046955100447607,-0.040461447217688,-0.032422198032309,-0.023736742584556,
		-0.015365062783593,-0.0082149644417353,-0.0030369939922087,-0.00033972385976285
	};

	boolean isFirFirst = true ;
	static final int numOfFirData = firCoef.length ;
	int firEntryPoint ;
	int[] firData = new int[ numOfFirData ] ;
	short fir( int data ) {
		if( isFirFirst ) {
			isFirFirst = false ;
			for( int i = 0 ; i < numOfFirData ; i ++ ) {
				firData[ i ] = 0 ;
			}
			firEntryPoint = 0 ;
		}
		firData[ firEntryPoint ] = data ;
		firEntryPoint ++ ;
		if( firEntryPoint >= numOfFirData ) {
			firEntryPoint = 0 ;
		}
		double ans = 0 ;
		int pnt = firEntryPoint ;
		for( int i = 0 ; i < numOfFirData ; i ++ ) {
			ans += firData[ pnt ] * firCoef[ i ] ;
			pnt ++ ;
			if( pnt >= numOfFirData ) {
				pnt = 0 ;
			}
		}
		return (short )ans ;
	}
	
	
	
	
	
	
	
	
	
}
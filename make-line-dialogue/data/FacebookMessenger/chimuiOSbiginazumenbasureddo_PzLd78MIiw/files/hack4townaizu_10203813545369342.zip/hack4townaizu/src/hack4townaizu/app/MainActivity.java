package hack4townaizu.app;

import java.util.Arrays;
import java.util.Locale;

import org.hack4townaizu.app.R;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Hack for Town in Aizu
 * @author iOS beginners 
 */
public class MainActivity extends Activity implements 	BluetoothAdapter.LeScanCallback,TextToSpeech.OnInitListener {
	
	/** request code for enabling BLUETOOTH */	protected static final int    REQUEST_CODE_ENABLE_BLUETOOTH = 0x0b;
	/** BLUETOOTH scan period(msec)			*/	protected static final int    BLUETOOTH_SCAN_PERIOD         = 60000;
	/** logging TAB							*/	protected static final String TAG = "sample";
	
	/** handler			*/	private Handler           _handler ;
	/** BT manager		*/	private BluetoothManager  _btmanager;
	/** BT adapter		*/	private BluetoothAdapter  _btadapter;
	/** vibrator		*/	private Vibrator          _vibrator;
	/** media player 	*/	private MediaPlayer       _player;
	/** text to speech	*/	private TextToSpeech      _tts;
	
	
	/* @see android.app.Activity#onCreate(android.os.Bundle) */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// BluetoothがOFFならONに
		_btmanager = BluetoothManager.class.cast( getSystemService(Context.BLUETOOTH_SERVICE) );
		_btadapter = _btmanager.getAdapter();
		if( _btadapter == null || !_btadapter.isEnabled() ) {
		    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
		    startActivityForResult(enableBtIntent,REQUEST_CODE_ENABLE_BLUETOOTH);		
		}
		
		// set connect button event
		Button.class.cast(findViewById(R.id.connectbtn)).setOnClickListener(new OnClickListener() {
        	public void onClick(View v) { connect(); }
        });
		// set disconnect button event
		Button.class.cast(findViewById(R.id.disconnectbtn)).setOnClickListener(new OnClickListener() {
			public void onClick(View v) { disconnect(); }
		});
		
		// Vibrator 
		_vibrator = Vibrator.class.cast(getSystemService(VIBRATOR_SERVICE));
		//_vibrator.vibrate(10000L);	// for test
		
		// Meida Player
		 _player = MediaPlayer.create(getApplicationContext(),R.raw.alarm);	// set mp3 file
		// _player.seekTo(0);	// for test
		// _player.start();		// for test
		
		// TextToSpeech
		_tts = new TextToSpeech(getApplicationContext(),this);
		
		// handler
		_handler = new Handler();
	}
	
	/* @see android.speech.tts.TextToSpeech.OnInitListener#onInit(int) */
	@Override
	public void onInit(int status) {
		// setting for TextToSpeech
	    if (TextToSpeech.SUCCESS == status) {
	        Locale locale = Locale.JAPANESE;
	        if (_tts.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE) { _tts.setLanguage(locale); } 
	        else { Log.d(TAG, "Error SetLocale"); }
	    } 
	    else { Log.d(TAG, "Error Init"); }
	}
 
	/* @see android.app.Activity#onStart() */
	@Override
	protected void onStart() {
		super.onStart();
		// connect();
	}
	
	/* @see android.app.Activity#onDestroy() */
	@Override
	protected void onDestroy() {
		disconnect();
		super.onDestroy();
	}
	
	/* @see android.app.Activity#onCreateOptionsMenu(android.view.Menu) */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	/**
	 * BLEスキャンを停止
	 */
	private void disconnect() {
		Log.v(TAG,"end connection");
		_btadapter.stopLeScan(MainActivity.this);

        TextView.class.cast(findViewById(R.id.statustext)).setText("stop scanning");
    }
	
	/**
	 * BLEスキャンを開始
	 */
	private void connect() {
		Log.v(TAG,"start connection");
		Toast.makeText(getApplicationContext(),"start scanning",Toast.LENGTH_SHORT).show();
		// 60秒後に自動的に停止
		_handler.postDelayed(new Runnable() {
			public void run() {
				_btadapter.stopLeScan(MainActivity.this);
			}
		}, BLUETOOTH_SCAN_PERIOD );
        // 一旦止めてからスキャン開始
		_btadapter.stopLeScan(this);
        _btadapter.startLeScan(this);
        TextView.class.cast(findViewById(R.id.statustext)).setText("scanning");
	}
	
	/* @see android.bluetooth.BluetoothAdapter.LeScanCallback#onLeScan(android.bluetooth.BluetoothDevice, int, byte[]) */
	@Override
    public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
		// BLEｋスキャン結果を受信
		BleData  bleid  = new BleData(scanRecord);	// スキャンレコードをパース
		String   uuid   = bleid.getUuid();
		
		// 指定したUUIDのみを対象に処理
		if (uuid.equalsIgnoreCase("4CC4242A882448E68ECD76101524C171")) {
			// 指定したMajorとMinorのペアを対象に処理
			if( TextUtils.equals(bleid.getMajor(),"0004") && TextUtils.equals(bleid.getMinor(),"0006") ) {
				// RSSIから距離を概算
				double dist = getDistance(bleid,rssi);
				Log.v(TAG,String.format("%s: %.04f (m)",device.getName(),dist));
				
				int vduration = 5000;      // msec
				String text   = "chikai";  // for TTS
				// case over 5 m
				if( dist >= 5 ) ;
				// case between 5 and 10 m
				else if( 3 <= dist && dist < 5 ) {
					vduration = 1000;
					text      = "chikai";
					_player   = MediaPlayer.create(getApplicationContext(),R.raw.alarm);
				}
				else {
					vduration = 5000;
					text = "yabai";
					_player = MediaPlayer.create(getApplicationContext(),R.raw.near);
				}
				
	           	// start vibration ////////////////////////////
	           	if( _vibrator.hasVibrator() ) { _vibrator.vibrate(vduration);  }
	           	// start media ////////////////////////////////
//	           	if( _player.isPlaying() ) { _player.stop(); }
//	           	else { 
//	           		_player.seekTo(0);
//	           		_player.start();
//	           	}
	           	// text to speech /////////////////////////////
	           	if( _tts.isSpeaking() ) { _tts.stop(); }
	           	else { _tts.speak(text, TextToSpeech.QUEUE_FLUSH, null); }
			}
    	}
    }
    
	/**
	 * RSSIからの距離概算
	 * @param bledata BLEレコード
	 * @param rssi　RSSI
	 * @return 距離(m)
	 */
    protected double getDistance(BleData bledata,int rssi) {
    	return Math.abs(1d - (rssi+59) * 10d / 20d);	// あくまでも概算
    }
    
    /**
     * バイト列のHEX文字列化
     * @param bytes バイト列
     * @return HEX文字列
     */
	public String toHexString(byte bytes[]) {
		StringBuffer buf = new StringBuffer();
		for(byte b:bytes) { buf.append( String.format("%02X",b) ); }
		return buf.toString();
	}


	/**
	 * BLEデータクラス
	 */
    private class BleData {
    	/** UUID	*/	private String _uuid;
    	/** major	*/	private String _major;
    	/** minor	*/	private String _minor;
    	/** TxPower	*/	private int    _txpower;
    	
    	/**
    	 * 初期化
    	 * @param bytes BLEレコード
    	 */
    	private BleData(byte bytes[]) {
        	_uuid    = toHexString(Arrays.copyOfRange(bytes, 9,25));
        	_major   = toHexString(Arrays.copyOfRange(bytes,25,27));
    		_minor   = toHexString(Arrays.copyOfRange(bytes,27,29));
    		_txpower = -(0x7f & Arrays.copyOfRange(bytes,29,30)[0]);
    	}

    	/**
    	 * UUID
    	 * @return　UUID
    	 */
    	private String getUuid() {
    		return _uuid;
    	}
    	/**
    	 * Major 
    	 * @return Major
    	 */
    	private String getMajor() {
    		return _major;
    	}
    	/**
    	 * Minor
    	 * @return Minor
    	 */
    	private String getMinor() {
    		return _minor;
    	}
    	/**
    	 * TxPower
    	 * @return TxPower
    	 */
    	private int getTxPower() {
    		return _txpower;
    	}
    }
}

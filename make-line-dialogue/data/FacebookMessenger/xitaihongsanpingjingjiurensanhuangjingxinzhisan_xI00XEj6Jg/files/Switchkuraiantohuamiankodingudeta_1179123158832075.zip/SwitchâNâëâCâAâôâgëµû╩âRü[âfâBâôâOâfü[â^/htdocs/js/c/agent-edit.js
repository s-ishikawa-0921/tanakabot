$(function(){
	$(document).on("click", ".remove-other a", function(event) {
		event.preventDefault();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().remove();
	});
	$(".add-other a").click(function() {
		var txtarea = 
'<h4 class="other-title">' + 
	'<input type="text" placeholder="その他（タイトルを変更する事ができます）">' + 
'</h4>' + 
'<p class="agent-text">' + 
	'<textarea></textarea>' + 
'</p>' + 
'<div class="text-count"><span>0</span> / 2,000文字</div>' + 
'<div class="remove-other"><a href="javascript:void(0);">その他情報を削除</a></div>';
		$(this).parent().before(txtarea);
	});
	
	setInterval(checkCount, 100);
	function checkCount() {
		$(".agent-text textarea").each(function(i) {
			var text = "<span>" + $(this).val().length + "</span> / 2,000文字";
			$(".text-count:eq(" + i + ")").html(text);
		});
	}
});


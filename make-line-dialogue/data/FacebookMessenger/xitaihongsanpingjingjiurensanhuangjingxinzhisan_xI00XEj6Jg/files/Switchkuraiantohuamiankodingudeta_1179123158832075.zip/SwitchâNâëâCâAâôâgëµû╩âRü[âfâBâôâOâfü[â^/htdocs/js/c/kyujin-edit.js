$(function(){
	// プレースホルダー
	$("textarea").each(function() {
		if ($(this).prev().hasClass("template")) {
			if ($(this).val() == $(this).prev().val()) {
				$(this).css({"color":"#999"});
			} else if ($(this).val() == "") {
				$(this).css({"color":"#999"});
				$(this).val($(this).prev().val());
			}
			
			$(this).focus(function() {
				if ($(this).val() == $(this).prev().val()) {
					$(this).css({"color":"#000"});
					$(this).val("");
				}
			}).blur(function() {
				if ($(this).val() == "") {
					$(this).css({"color":"#999"});
					$(this).val($(this).prev().val());
				}
			});
		}
	});
	
	var $target = $(".profile_career-edit textarea").not(".template");
	var $template = $(".profile_career-edit textarea.template");
	if ($target.val() == $template.val()) {
		$target.css({"color":"#999"});
	} else if ($target.val() == "") {
		$target.css({"color":"#999"});
		$target.val($template.val());
	}
	$target.focus(function() {
		if ($target.val() == $template.val()) {
			$target.css({"color":"#000"});
			$target.val("");
		}
	}).blur(function() {
		if ($target.val() == "") {
			$target.css({"color":"#999"});
			$target.val($template.val());
		}
	});
	
	
	
	$(document).on("click", ".remove-area a", function(event) {
		event.preventDefault();
		$(this).parent().prev().remove();
		$(this).parent().remove();
	});
	$(".add-area a").click(function() {
		var txtarea = 
'<p class="form-area">' + 
	'<textarea></textarea>' + 
'</p>' + 
'<div class="remove-area"><a href="javascript:void(0);">勤務地を削除</a></div>';
		$(this).parent().before(txtarea);
	});
	
	$(document).on("click", ".tab01 .remove-other a", function(event) {
		event.preventDefault();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().remove();
	});
	$(".tab01 .add-other a").click(function() {
		var txtarea = 
'<div class="form-other">' + 
	'<p class="form-title">' + 
		'<input type="text" placeholder="その他（タイトルを変更する事ができます）">' + 
	'</p>' + 
	'<p class="form-text">' + 
		'<textarea></textarea>' + 
	'</p>' + 
	'<div class="text-count"><span>0</span> / 2,000文字</div>' + 
'</div>' + 
'<div class="remove-other"><a href="javascript:void(0);">その他情報を削除</a></div>';
		$(this).parent().before(txtarea);
	});
	
	$(document).on("click", ".tab02 .remove-other a", function(event) {
		event.preventDefault();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().prev().remove();
		$(this).parent().remove();
	});
	$(".tab02 .add-other a").click(function() {
		var txtarea = 
'<h4 class="other-title">' + 
	'<input type="text" placeholder="その他（タイトルを変更する事ができます）">' + 
'</h4>' + 
'<p class="info-detail-text">' + 
	'<textarea></textarea>' + 
'</p>' + 
'<div class="text-count"><span>0</span> / 2,000文字</div>' + 
'<div class="other-photo clearfix">' + 
	'<div class="add-other-photo photo1">' + 
		'<div class="add-btn">' + 
			'<input type="file" class="input-file">' + 
			'<div class="add-btn-text"><span>画像を選択してください</span><br>推奨サイズ：240×180　最大5MB JPEG形式</div>' + 
		'</div>' + 
	'</div>' + 
	'<div class="add-other-photo photo2">' + 
		'<div class="add-btn">' + 
			'<input type="file" class="input-file">' + 
			'<div class="add-btn-text"><span>画像を選択してください</span><br>推奨サイズ：240×180　最大5MB JPEG形式</div>' + 
		'</div>' + 
	'</div>' + 
'</div>' + 
'<div class="remove-other"><a href="javascript:void(0);">その他情報を削除</a></div>';
		$(this).parent().before(txtarea);
	});
	
	setInterval(checkCount, 100);
	function checkCount() {
		$(".info-text textarea, .info-detail-text textarea, .form-other textarea").each(function(i) {
			var text = "<span>" + $(this).val().length + "</span> / 2,000文字";
			$(this).parent().next().html(text);
		});
	}
});


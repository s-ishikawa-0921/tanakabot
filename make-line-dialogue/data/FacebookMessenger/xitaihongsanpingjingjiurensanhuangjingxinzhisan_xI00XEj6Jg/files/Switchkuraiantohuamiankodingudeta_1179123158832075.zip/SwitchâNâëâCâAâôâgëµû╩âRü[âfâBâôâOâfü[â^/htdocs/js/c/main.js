
// $(document).ready(function() {
// 	$("a").currentPage();
// });

var ANIMATION_SPEED = 200;
var hoverIntervalArray = [];
function hoverList(index) {
	clearTimeout(hoverIntervalArray[index]);
	hoverIntervalArray[index] = -1;
	
	$('.job:eq(' + index + ')').find('.over-show').each(function() {
		if ($(this).hasClass("btn-top")) {
			$(this).css({top: -15, height: 0, opacity: 0, display:"block"});
			$(this).stop().animate( { top: -55, opacity: 1 }, ANIMATION_SPEED );
		} else {
			$(this).css({top: -50, height: 0, opacity: 0, display:"block"});
			$(this).stop().animate( { top: -95, opacity: 1 }, ANIMATION_SPEED );
		}
	});
	$('.job:eq(' + index + ')').find(".card-inner").stop().animate({opacity: 0.7}, ANIMATION_SPEED);
}

$(function(){
	$page = $.url().attr('file');
	if(!$page) {
		$page = '/';
	}
	$('.nav-lists a').each(function(){
		var $href = $(this).attr('href');
		if ( ($href == $page) || ($href == '') ) {
			$(this).addClass('current');
		} else {
			$(this).removeClass('current');
		}
	});

	//設定ボタンプルダウン
	$('#setting-btn').mouseover(function() {
		$('#setting-box').fadeIn("fast");
		$('#layer').fadeIn("fast");
	});
	$('#layer').mouseover(function() {
		$('#setting-box').fadeOut("fast");
		$('#layer').fadeOut("fast");
	});

	//job submenu
	if($('.job').children().hasClass('blur')){
		$(this).find('.over-show').hide();
	} else {
		$('.job').each(function(i) {
			hoverIntervalArray[i] = -1;
		});
		
		$('.job').hover(function(){
			if ($(".open").size() == 0) {
				var index = $('.job').index($(this));
				hoverIntervalArray[index] = setTimeout("hoverList(" + index + ")", 600);
			}
		}, function() {
			if ($(".open").size() == 0) {
				var index = $('.job').index($(this));
				if (hoverIntervalArray[index] != -1) {
					clearTimeout(hoverIntervalArray[index]);
					hoverIntervalArray[index] = -1;
					return;
				}
				
				$(this).find('.over-show').each(function() {
					if ($(this).hasClass("btn-top")) {
						//$(this).css({top: -55, height: 0, opacity: 1, display:"block"});
						$(this).stop().animate( { top: -15, opacity: 0 }, ANIMATION_SPEED , function() {
							$(this).css({display:"block"});
						});
					} else {
						//$(this).css({top: -95, height: 0, opacity: 1, display:"block"});
						$(this).stop().animate( { top: -50, opacity: 0 }, ANIMATION_SPEED , function() {
							$(this).css({display:"block"});
						});
					}
				});
				$(this).find(".card-inner").stop().animate({opacity: 1}, ANIMATION_SPEED);
			}
		});
	}

	//パネル開閉
	var CARD_MARGIN_BOTTOM = 15;
	$('.btn-top').click(function(){
		
		if ($(".open").size() == 1 && $('.btn-top').index($(this)) == $('.btn-top').index($(".open"))) {
			$(this).parent().find('.over-show').each(function() {
				if ($(this).hasClass("btn-top")) {
					$(this).stop().animate( { top: -55, height: 0}, 200 );
				} else {
					$(this).stop().animate( { top: -95, height: 0}, 200 );
				}
			});
		} else {
			$(this).parent().find(".nav-tabs li").removeClass("active");
			$(this).parent().find(".nav-tabs li:eq(0)").addClass("active");
			$(this).parent().find(".tab-content .tab-pane").removeClass("active");
			$(this).parent().find(".tab-content .tab-pane:eq(0)").addClass("active");
			
			$(this).toggleClass("open");
			$(this).parent().find('.over-show').each(function() {
				if ($(this).hasClass("btn-top")) {
					$(this).css({top: -55, height: 40});
					$(this).stop().animate( { top: 0, height: 40}, 200 );
				} else {
					$(this).css({top: -55, height: 40});
					$(this).stop().animate( { top: 0, height: 40}, 200 );
				}
			});
		}

		$(this).next('.panel').slideToggle('slow');
		//$(this).toggleClass("open");

		var obj = { height: 'toggle', opacity: 'toggle' };
		if ($(this).parent().find(".card-inner").css("margin-bottom") == "15px") obj["margin-bottom"] = 0;
		else obj["margin-bottom"] = CARD_MARGIN_BOTTOM;
		if (obj["margin-bottom"] == 15) {
			$(this).parent().find(".card-inner").stop().animate( obj, 'slow', function() {
				$(".open").toggleClass("open");
			} );
		} else {
			$(this).parent().find(".card-inner").stop().animate( obj, 'slow' );
		}
	});
	$('.btn-bottom').click(function(){
		var $li = $(this).parent().parent();
		
		$('html,body').scrollTop($li.offset().top);
		$li.find('.card-inner').stop().animate( { height: 'toggle', "margin-bottom": 15, opacity: 'toggle' }, 0 );
		$li.find('.over-show').stop().animate( { top: 0, height: 0, opacity: 0 }, 0 );
		$(this).parent('.panel').slideToggle(0);
		$li.find('.btn-top').toggleClass("open");
	});

	//checkbox全選択、全解除
	$('.all-check input,.all-check label').click(function(){
		var items = $(this).closest('.tab-pane').find('.checkbox-lists input');
		if($(this).is(':checked')) {
			$(items).prop('checked', true); 
		} else { 
			$(items).prop('checked', false); 
		}
	});

	//セレクトボックス カスタマイズ
	$('.design-select-box').easySelectBox({onClick:selectionStatus});
	// 選考状況選択した場合の処理
	function selectionStatus(data) {
		if ($(this).closest(".job").length > 0) $(this).closest(".job").find(".design-select-box").easySelectBox("select", data.text);
	}

	// $('.tab-pane input').change(function(){
	// if($('.tab-pane input:checkbox:checked').length < 1) {
	// 	var index = $(this).closest('.tab-pane').index();
	// 	console.log(index);
	// 	$('.nav-pills li').eq(index).find('.check').hide();
	// } 
	// });
	$('.tab-pane input').change(function(){
		var index = $(this).closest('.tab-pane').index();
		var $count = $(this).closest('.tab-pane input[type=checkbox]:checked').length;

		if ($(this).is(':checked')) {
			$('.nav-pills li').eq(index).find('.check').show();
		} else if($('.tab-pane.active input[type=checkbox]:checked').length < 1){
			// var index = $(this).closest('.tab-pane').index();
			// console.log(index);
			$('.nav-pills li').eq(index).find('.check').hide();
		}
	});

	//詳細タブ切り替え
	$(document).on("click", ".nav-tabs a", function(event) {
		event.preventDefault();

		var $tabarea = $(this).closest(".panel-body");
		var index = $tabarea.find(".nav-tabs a").index(this) + 1;
		console.log(index);
		$tabarea.find(".tab-content > div").removeClass("active");
		var $tabcontents = $tabarea.find(".tab-content #nav-0" + index).addClass("active");
	});

	//メッセージ開閉
	$(document).on("click", ".msg-send a", function(event) {
		event.preventDefault();
		
		if ($(".open").length > 0) return;
		
		var $job = $(this).closest(".job");
		$job.find(".nav-tabs li").removeClass("active");
		$job.find(".nav-tabs li:eq(3)").addClass("active");
		$job.find(".tab-content .tab-pane").removeClass("active");
		$job.find(".tab-content .tab-pane-message").addClass("active");
		
		var $target = $job.find(".btn-top");
		$target.css({display:"block", opacity:0});
		
		var index = $('.job').index($(this).closest(".job"));
		if (hoverIntervalArray[index] != -1) {
			clearTimeout(hoverIntervalArray[index]);
			hoverIntervalArray[index] = -1;
		}
		
		$target.toggleClass("open");
		$target.parent().find('.over-show').each(function() {
			if ($(this).hasClass("btn-top")) {
				$(this).css({top: -55, height: 40});
				$(this).stop().animate( { top: 0, height: 40, opacity: 1 }, 200 );
			} else {
				$(this).css({top: -55, height: 40});
				$(this).stop().animate( { top: 0, height: 40, opacity: 1 }, 200 );
			}
		});

		$target.next('.panel').slideDown('slow');

		var obj = { height: 'toggle', opacity: 'toggle' };
		if ($target.parent().find(".card-inner").css("margin-bottom") == "15px") obj["margin-bottom"] = 0;
		else obj["margin-bottom"] = CARD_MARGIN_BOTTOM;
		if (obj["margin-bottom"] == 15) {
			$target.parent().find(".card-inner").stop().animate( obj, 'slow', function() {
				$(".open").toggleClass("open");
			} );
		} else {
			$target.parent().find(".card-inner").stop().animate( obj, 'slow' );
		}
	});

	//アクションバー追従
	$(window).scroll(function() {
		if ($(".open").size() == 1) {
			var $li = $(".open").parent();
			var $t = $li.find(".over-show:not(.btn-top)");
			var $jobcontents = $li.find("#job-contents");
			
			var st = $(window).scrollTop();
			if (st > $li.offset().top) {
				var top = st - $li.offset().top;
				if (top > $jobcontents.height() + $t.height()) top = $jobcontents.height() + $t.height();
				$t.css({top:top});
			} else {
				$t.css({top:0});
			}
		}
	});
	
	//完了しました。
	$('.page-index .job').find('.submenu-like').click(function(event) {
		$('.popup-complete').fadeIn();
		$('.popup-complete').click(function(event) {
			$('.popup-complete').fadeOut();
		});
		setTimeout(function() {
			$('.popup-complete').fadeOut();
		}, 2000);

	});
	$('.page-scout .job').find('.submenu-like').click(function(event) {
		$('.popup-complete').fadeIn();
		$('.popup-complete').click(function(event) {
			$('.popup-complete').fadeOut();
		});
		setTimeout(function() {
			$('.popup-complete').fadeOut();
		}, 2000);

	});
	//エラー
	$('.page-index .job').find('.submenu-close').click(function(event) {
		$('.error-modal').modal();
	});
	$('.page-scout .job').find('.submenu-close').click(function(event) {
		$('.error-modal').modal();
	});
	$('.page-scout .job').find('.submenu-close2').click(function(event) {
		$('.error-modal').modal();
	});
	
	//検索
	$('.search-close').click(function() {
		$('.offer-search').slideUp('fast');
		$('.search-close').hide();
		$('.search-open').show();
	});
	$('.search-open').click(function() {
		$('.offer-search').slideDown('fast');
		$('.search-close').show();
		$('.search-open').hide();
	});
	$('.lang01 .add-lang').click(function() {
		$('.lang02').slideDown('fast');
		$('.lang01 .add-lang').hide();
	});
	$('.lang02 .add-lang').click(function() {
		$('.lang03').slideDown('fast');
			$('.lang02 .add-lang').hide();
	});
	$('#modal-register .btn-register input').click(function() {
		$('#modal-register').modal('hide');
		if ($(this).parent().parent().find("input[type='checkbox']").prop('checked')) $('#modal-register2').modal();
	});

	//スカウト送る
	$('.page-offer .job').find('.submenu-like').click(function(event) {
		$('#modal-job').modal();
	});
	$('.page-offer .job').find('.submenu-bookmark').click(function(event) {
		$('#modal-job2').modal();
	});
	$('#modal-job .decision').click(function() {
		$('#modal-job').modal('hide');
		$('#modal-scout').modal();
	});
	$('#modal-job2 .decision').click(function() {
		$('#modal-job2').modal('hide');
		$('#modal-bookmark').modal();
	});
	$('.page-offer .job').find('.submenu-open-alert').click(function(event) {
	$('#modal-job3').modal();
	});
	$('#modal-job3 .decision').click(function() {
		$('#modal-job3').modal('hide');
		$('#modal-scout-error').modal();
	});

	//メッセージスカウト送る
	$('.page-scout .job').find('.submenu-message').click(function(event) {
		$('#modal-message').modal();
	});


//メモを開く
	$('.text-block').find('.memo').click(function(event) {
		$('#modal-memo').modal();
	});

	
	$('.tab-pane-body input').change(function(){
		var index = $(this).closest('.tab-pane').index();
		// var $count = $(this).closest('.tab-pane input[type=checkbox]:checked').length;
		if ($(this).is(':checked')) {
			$(this).parent().parent().parent().parent().parent().parent().parent().find('.nav-pills li').eq(index).find('.check').show();
		} else if($(this).parent().parent().parent().parent().parent().parent().find('.tab-pane.active input[type=checkbox]:checked').length < 1){
			$(this).parent().parent().parent().parent().parent().parent().parent().find('.nav-pills li').eq(index).find('.check').hide();
		} 
	});

$(".detail-head").on("click", function() {
    $(this).next().slideToggle();
				$(this).toggleClass("open")
	});

	$('#modal-jobadpot01 .seeker-list li').click(function() {
		$('#modal-jobadpot01').modal('hide');
	});

	$('#modal-jobadpot02 .project-list li').click(function() {
		$('#modal-jobadpot02').modal('hide');
	});

});


/* ===============================================
お知らせ
=============================================== */
$(function(){
	$('.page-oshirase .all-select input').click(function(){
		var items = $('.page-oshirase #accordion-oshirase').find('input');
		if($(this).is(':checked')) { 
			$(items).prop('checked', true); 
		} else { 
			$(items).prop('checked', false);
		};
	});
	$('.page-oshirase .all-select .btn').click(function(){
		var items = $('.page-oshirase #accordion-oshirase .panel input');
		if($(items).is(':checked')) { 
			$(items).next('a').removeClass('unread'); 
		};
	});
});


/* ===============================================
チャート制御
=============================================== */
$(function(){
	if( $(".user-profile-status").length) {
		var Percent = $(".user-profile-status > p em").text() + "%";
		setTimeout(function(){
			$(".user-profile-status div div").css("width", Percent);
		},300);
	}
});


/* ===============================================
コメント入力
=============================================== */
$(function(){
	if($(".message-wrap").length){
		areaLine = 1;
		areaHeight = 0;
		areaMaxHeight = 0;
		areaFlg = false;
		var areaTarget = $(".message-chat-input textarea");
		areaTarget.each(function(){
			autosize(this);
			areaHeight = areaTarget.height();
			areaFlg = true;
		}).on("autosize:resized", function(){
			if(areaFlg == false){
				areaLine = 6;
				areaFlg = true;
			}
			if(areaTarget.height() > areaHeight){
				areaLine ++;
			}else{
				areaLine --;
			}
			areaHeight = areaTarget.height();
			if(areaLine == 5) areaMaxHeight = parseInt(areaTarget.css("height"),10);
			if(areaLine > 5 && areaFlg == true){
				autosize.destroy(areaTarget);
				areaTarget.css({
					'height':areaMaxHeight + "px"
				});
				areaTarget.animate({scrollTop: areaTarget[0].scrollHeight},'fast');
				areaFlg = false;
			}
			//msgMainSet();
		}).on("input", function(evt){
			if(evt.target.scrollHeight <= evt.target.offsetHeight && areaFlg == false){
				autosize(areaTarget);
			}
		});
	}
});


/* ===============================================
ファイルアップロード選択
=============================================== */
$(function(){
  if($(".message-file-select").length){
    $(".file-select").change(function(){
      $(".file-text").val($(".file-select").val());
    });
    $(".file-text").click(function(){
        $(".file-select").click();
    });
  }
});


/* ===============================================
メッセージ入力欄表示
=============================================== */
$(function(){
  if($(".message-wrap").length){
	$(".message-wrap").hide();
    $('.no-reply-list-wrap > a').click(function(){
		$(this).next(".message-wrap").slideToggle(300);
		return false;
	});
  }
});


/* ===============================================
サンプルリスト表示
=============================================== */
$(function() {
  $(".message-temp")
    .mouseover(function() {
      $(this).find(".message-temp-list").show();
    })
    .mouseout(function() {
      $(this).find(".message-temp-list").hide();
    });
});


/* ===============================================
スカウト検索　選択モーダル表示
=============================================== */
$(function() {
	$(".mdl-input").click(function(){
		var mdlType = $(this).attr("data-select");
		var mdlTarget = ".mdl-" + mdlType;
		$("body").addClass("is-scl");
		$(".mdl-bg").show();
		$(mdlTarget).show();
		return false;
	});
});


/* ===============================================
スカウト検索　選択モーダル非表示
=============================================== */
$(function() {
	$(".mdl-cancel").click(function(){
		$(".mdl-bg").hide();
		$(".mdl-cnt").hide();
		$("body").removeClass("is-scl");
		return false;
	});
});


/* ===============================================
スカウト検索　選択モーダル 選択完了
=============================================== */
$(function() {
	$(".mdl-complete").click(function(){
		var mdlType = $(this).closest(".mdl-cnt").attr("data-mdl");
		$('p[data-select='+mdlType+']').closest("dd").find("span").remove();
		$(this).closest(".mdl-cnt").find(".mdl-select-main input").each(function(){
			if($(this).prop("checked")) {
				var selectLabel = $(this).next("label").text();
				$('p[data-select='+mdlType+']').next(".label-wrap").append('<span class="select-label" data-label="'+$(this).attr("id")+'"><a href="#">'+selectLabel+'</a></span>');
			}
		});
		$(".mdl-bg").hide();
		$(".mdl-cnt").hide();
		$("body").removeClass("is-scl");
		return false;
	});
});

/* ===============================================
スカウト検索　求人選択モーダル 選択完了
=============================================== */
$(function() {
	$(".mdl-complete-jobinfo").click(function(){
		var mdlType = $(this).closest(".mdl-cnt").attr("data-mdl");
		$(".label-jobinfo").find("span").remove();
		$(this).closest(".mdl-cnt").find(".mdl-select-main li input").each(function(){
			if($(this).prop("checked")) {
				var selectLabel = $(this).next("label").text();
				$(".label-jobinfo").append('<span class="select-label" data-label="'+$(this).attr("id")+'"><a href="#">'+selectLabel+'</a></span>');
			}
		});
		$(".mdl-bg").hide();
		$(".mdl-cnt").hide();
		$("body").removeClass("is-scl");
		return false;
	});
});


/* ===============================================
スカウト検索　選択ラベル解除
=============================================== */
$(function() {
	$(".label-wrap").on('click','span',function() {
		var targetLabel = $(this).attr("data-label");
		$("input#"+targetLabel).prop("checked",false);
		$(this).remove();
		return false;
	});
});


/* ===============================================
スカウト検索　言語を追加
=============================================== */
$(function() {
	$(".search-add-lang a").click(function(){
		var langData = $(".frm-lang select option:selected").text();
		var studyData = $(".frm-study select option:selected").text();
		if (!langData.match(/選ぶ/) && !studyData.match(/選ぶ/)){
			$(".label-lang-wrap").append('<span class="select-label"><a href="#">'+langData+'　'+studyData+'</a></span>');
		}
		return false;
	});
});

/* ===============================================
スカウト検索　言語を削除
=============================================== */
$(function() {
	$(".label-lang-wrap").on('click','span',function() {
		$(this).remove();
		return false;
	});
});

/* ===============================================
スカウト検索　さらに絞り込む
=============================================== */
$(function() {
	$(".more-search a").click(function(){
		$(".search-more-main").slideToggle(300,function(){
			$(".more-search").toggleClass("more-close");
			if($(".more-close").length){
				$(".more-search span").text("閉じる");
			}else{
				$(".more-search span").text("さらに絞り込む");
			}
		});
		return false;
	});
});

/* ===============================================
スカウト検索　モーダル内切替
=============================================== */
$(function() {
	$(".mdl-select-nav a").click(function(){
		var targetIndex = $(this).closest("li").index();
		$(this).closest(".mdl-select-wrap").find(".mdl-select-list").hide().eq(targetIndex).show();
		return false;
	});
});

/* ===============================================
ページ内スクロール
=============================================== */
$(function() {
	$('a[href^="#"]').click(function(){
		var elmID = ($(this).attr('href')) ? $(this).attr('href') : '.app-container';
		if($(elmID).size()){
			posi = $(elmID).offset().top;
			$('html,body').animate({
			scrollTop: posi
			}, 500);
			return false;
		}
	});
});

$(function(){
	setInterval(checkModalReplyCount, 100);
	function checkModalReplyCount() {
		if ($("#modal-message").length == 1 && $("#modal-message").find(".reply-top textarea").length > 0) {
			var text = "<span>" + $("#modal-message").parent().find(".reply-top textarea").val().length + "</span> / 2,000文字";
			$("#modal-message").parent().find(".text-count").html(text);
		}
	}
});

